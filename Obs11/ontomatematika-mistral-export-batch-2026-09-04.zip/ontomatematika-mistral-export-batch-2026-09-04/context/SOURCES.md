# Source receipt

This is a curated snapshot, not a complete workspace export. Notion remains the source of truth.

| Source | Page ID | Version/status | Used for |
| --- | --- | --- | --- |
| ONTOMATEMATIKA Kernel v0.1 | `093a8691-9b5c-4a00-aa74-b9f2f607f1f7` | Testing, not sealed | Mission, core loop, additive value, Mistral policy |
| ONTOMATEMATIKA Kernel v0.1 Spec | `b54232be-ffea-46f9-b6a5-d32fd42c3314` | Provisional boot layer | Axioms, symbols, validation, open gaps |
| ONTOMATEMATIKA Grammar v0.1 | `3cd70000-bf2e-8132-88b2-c30616734dd9` | Draft / needs review | Formation and token resolution |
| Ontological Restrictions for Play v0.1 | `99ef2079-fd3e-4943-8a03-cfa270e9fd60` | Grounded / diagnostic / spec | Restriction pipeline and outcomes |
| Search-First Remedy Protocol v0.1 | `dc8afdb7-c061-49aa-99ac-6e8021bb3585` | Active operating rule | Source-first behavior and handoff requirements |
| Able–Mistral–Cline Delegation Protocol | `51f0c776-90ef-48f3-9327-0bdce279de6b` | Active protocol | Actor roles and routing |
| Cline Prompt Templates | `29f1edea-5be3-4d0d-89dd-5088514f426e` | Active template | Mistral output shape |
| Runtime Export Schema v0.1 | `6dde7b6c-6264-488a-9b2f-d9e57937d156` | v0.1 | Read-only curated export principle |
| Cline ↔ Notion Immediate Integration Spec | `8163db9e-78b5-41a3-8e62-61b9e1fb5587` | Current integration sequence | Reads first, proposals later, no live writes now |
| CL-033 | `96cda5bd-9cd6-4bee-b4b6-ca4224ca490e` | In progress | Active bounded UI task |
| ONTOMATEMATIKA Glossary (SL/EN) | `d4bd97d8-517d-4034-89d1-de897198b5ab` | Seed + runtime expansion | Stable vocabulary |

## Known open gaps

- Several symbols and agent meanings remain provisional or scope-sensitive.
- Kernel v0.1 is not SEALed.
- Registry alignment remains active.
- The repository's actual structure must be inspected before selecting implementation paths.
- This batch does not contain secrets or live Notion credentials.

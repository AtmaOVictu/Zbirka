# Guardrails and restriction pipeline

## Required pipeline

```text
Ref-context
→ scope
→ contradiction
→ evidence
→ harm budget
→ non-erasure
→ Guard
→ Ω / cycle completion
→ SEAL or Residual ℜ
→ Luka review when high-risk
```

## Central doctrine

- Every interaction is a claim.
- Every claim has a scope.
- Contradiction inside the same scope becomes instability or a Problem.
- Tension across scopes may be valid difference.
- Every risky action needs harm accounting.
- Every cut preserves being, personhood, provenance, and legacy meaning.
- Every unresolved answer becomes Residual or a Problem.

## Runtime outcomes

Use these labels where applicable:

`Present`, `Distinct`, `Scoped`, `Witnessed`, `Responsible`, `Whole`, `Sealable`, `Sealed`, `Residual named`, `Problem generated`, `STOP`, `Review required`.

Avoid generic correct/incorrect labels, unexplained success, and reward-first behavior.

## Batch-specific write policy

The long-term Kernel describes typed Draft, System, Risk, and SEAL writes. This export batch intentionally narrows that policy:

- **Allowed:** local analysis, implementation suggestions, code drafts, tests, and a Cline prompt.
- **Not allowed:** direct Notion mutation of any kind.
- **Not allowed:** canonical symbol decisions, ethics changes, destructive cleanup, SEAL, deletion, merge, or irreversible schema changes.

If uncertainty changes meaning, destination, safety, or permission, stop and ask or downgrade the output to an explicitly labeled draft.

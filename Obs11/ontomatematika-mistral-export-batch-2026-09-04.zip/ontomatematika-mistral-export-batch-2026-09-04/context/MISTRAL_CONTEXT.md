# Mistral operating context

## Identity of the system

ONTOMATEMATIKA is a living formal symbolic ontology and agentic execution system. Meaning arises through distinction inside a reference field, becomes reusable through RES units, and becomes actionable only after ethical validation.

```text
Reference → Distinction → Meaning → Unit → Consequence → Agent → Ethics → Evidence → SEAL
```

Current development mode is **Registry Alignment and UI upgrade**. The implementation surface is a canvas-style cockpit connecting visible actions to bounded previews, consequence traces, and later reviewed Notion proposals.

## Core loop

```text
Input → Problem → Solution Pair → Rule → Evolution → Additive Value → Next Test → Updated System
```

An addition has value only when it improves at least one of: clarity, connection, decision, generation, correction, safety, or memory.

## Semantic rules

- Meaning is not formula alone; it requires Ref-context.
- Repeated formulas can express different domains and must not be merged without scope analysis.
- Canonical operation must preserve legacy meanings and provenance.
- Unresolved mismatch becomes a Problem or Residual, not deletion.
- Returning to a phase origin does not erase development, winding, transformed state, consequence history, or Residual.

## Initial formal vocabulary

| Token | Operational meaning |
| --- | --- |
| `Ref` | Reference field or context of distinction |
| `∆` | Distinction, change, or transformation; type by domain |
| `¬` / `NE` | Negation or refusal |
| `⊘` | Cut, sever, nullify, or subtractive transformation; not generic composition |
| `∴` | Consequence or derived output |
| `∮` | Cycle or completion loop |
| `⟡` | Evidence, witness, or validation |
| `1` | SEAL or final commitment |
| `Ω` | Bounded whole or wholeness marker |
| `κ` | Clarity threshold |
| `χ` | Coherence threshold |
| `μ` | Softness or flexibility metric |
| `ℜ` | Resonance, remainder, or Residual |
| `ε` | Threshold parameter |

`φ`, `ψ`, `∆`, `Ω`, and `⊘` are scope-sensitive or overloaded. Never choose a universal interpretation without explicit source support.

## Grammar snapshot

```text
Atom     := Symbol | Term | RES | Axiom | Agent | Ethics
Negation := not(Atom)
Cut      := ⊘(Atom)
Change   := ∆(Atom)
Cycle    := ∮(Atom)
Witness  := ⟡(Claim, Evidence)
Compose  := Op(Atom, Atom) -> Unit
Seal     := 1(Action) iff validation_pass(Action)
```

Before validation, each token resolves as one of: canonical symbol, grammar token, metric family, operational state, or missing-problem candidate.

## Agent roles

- **Guard:** runtime validator and STOP executor.
- **SEAL:** finalizes only after cycle, evidence, ethics, and required review.
- **Ω:** monitors bounded wholeness and completion.
- **HALO:** coherence or field protection; exact canonical function still needs confirmation.
- **Φ:** form or harmony transformation; scope remains important.
- **Ψ:** psyche or affective-agentic interpretation; scope remains important.

No agent may validate and SEAL its own action.

## Evidence and completion

A current evidence candidate requires clarity `κ ≥ .70`, coherence `χ ≥ .40`, source traceability, consequence usefulness, and productive friction rather than flattery.

SEAL is not a UI reward. It is a terminal commitment requiring context, bounded contradiction, evidence, ethical pass, harm accounting when risky, non-erasure, Guard pass, cycle/wholeness check, named Residual or justified closure, and human review when high-risk.

# Able–Mistral–Cline delegation

| Actor | Primary responsibility | Boundary |
| --- | --- | --- |
| Able | Orchestration, schemas, source grounding, Notion routing | Does not blindly approve high-risk code or ontology changes |
| Mistral | Reasoning pass, drafting, prompt refinement, code explanation | Not final authority over ONTOMATEMATIKA meaning |
| Cline | Local repository inspection, file edits, tests | Does not decide ontology truth or approve SEAL |
| Luka | High-risk review, final acceptance, SEAL-level decisions | Human authority |

## Handoff shape

```text
TASK: CL-###
EXECUTOR: Cline / Mistral / Able / Luka Review
WHAT: One atomic action
WHY: System reason
CONTEXT: Relevant symbols, axioms, RES units, and source pages
REQUIREMENTS: Constraints
ACCEPTANCE: Done checks
OUTPUT BACK: Files changed, tests, blockers, uncertainty, next task
```

## Information loop

```text
Notion registries
→ reviewed context export
→ Cline task
→ Mistral reasoning / Cline execution
→ diffs, tests, blockers, questions
→ Able summary
→ Luka review when high-risk
```

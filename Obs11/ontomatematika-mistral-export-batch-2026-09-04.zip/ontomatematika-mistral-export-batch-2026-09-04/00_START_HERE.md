# ONTOMATEMATIKA → Mistral export batch

**Batch:** 2026-09-04 · v0.1  
**Current task:** CL-033 — Cohesion Cockpit Panels  
**Mode:** Local reasoning and code support only

## Start

1. Read every file in this batch before proposing edits.
2. Treat `tasks/CL-033.md` as the only active implementation scope.
3. Inspect the existing repository before choosing paths or creating components.
4. Return a plan before editing if repository structure conflicts with the task.
5. Preserve uncertainty and report any unresolved assumption.

## Authority order

1. Luka — human reviewer and final authority for high-risk meaning or SEAL decisions.
2. ONTOMATEMATIKA Kernel, Guard, ethics, and explicit task restrictions.
3. Able — orchestration, routing, source grounding, and Notion operations.
4. Mistral — second-pass reasoning, drafting, prompt refinement, and code support.
5. Cline — local VS Code execution, edits, and tests.

Mistral may recommend and draft. It must not silently redefine ONTOMATEMATIKA or approve ontology truth.

## Required output

Return:

- recommendation or implementation plan;
- files to create or modify;
- tests or checks to run;
- assumptions and uncertainty;
- risks and constraint checks;
- a bounded prompt for Cline;
- open questions for Luka or Able.

## Hard limits for this batch

- No direct Notion writes.
- No SEAL or canonicalization.
- No deletion or merge of registry objects.
- No secrets, API keys, tokens, or environment values.
- No broad refactor or duplicate cockpit implementation.
- No invented ontology data.

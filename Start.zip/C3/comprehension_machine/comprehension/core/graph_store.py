"""
Relation Field — TAZV Comprehension Machine
=============================================
SO-OBSTAJANJE Protocol: relation is primary (P4).

Not a graph of nodes and edges. A FIELD of relation-events.
Words emerge from relations, not the other way around.

"Storage Primitive = Relation. Operational Primitive = Difference."

What changed from the old version:
  OLD: GraphNode (standalone) → GraphEdge (connects nodes)
  NEW: RelationEvent (primary) → Resonance (co-existence between events)

  OLD: nodes are added first, edges second
  NEW: events ARE the field; resonances are how they co-exist

  OLD: promote_relation_to_node (hypergraph workaround)
  NEW: relations are already the primary unit — no promotion needed

Relation types from JEWIK Truthbase Studio:
  SUPPORTS, CONTRADICTS, DEFINES, REFINES, TESTS, SYMBOLICALLY_LINKED
Archive types: direct, semantic, compositional, derived, custom
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Set, Tuple
from enum import Enum
import uuid


class RelationType(str, Enum):
    SUPPORTS = 'SUPPORTS'
    CONTRADICTS = 'CONTRADICTS'
    DEFINES = 'DEFINES'
    REFINES = 'REFINES'
    TESTS = 'TESTS'
    SYMBOLICALLY_LINKED = 'SYMBOLICALLY_LINKED'
    DIRECT = 'direct'
    SEMANTIC = 'semantic'
    COMPOSITIONAL = 'compositional'
    DERIVED = 'derived'
    CUSTOM = 'custom'


RELATION_TYPE_LABELS: Dict[str, str] = {
    'SUPPORTS': 'podpira', 'CONTRADICTS': 'protislovje',
    'DEFINES': 'definira', 'REFINES': 'izboljša',
    'TESTS': 'preverja', 'SYMBOLICALLY_LINKED': 'simbolno povezano',
    'direct': 'neposredno', 'semantic': 'semantično',
    'compositional': 'sestavljeno', 'derived': 'izvedeno', 'custom': 'po meri',
}


class Severity(str, Enum):
    NIZKA = 'nizka'
    SREDNJA = 'srednja'
    VISOKA = 'visoka'


@dataclass
class Resonance:
    """
    Not an edge between two nodes. A resonance between two events.

    P4: relation is primary. This IS the primary unit.
    The events it connects are its faces, not its endpoints.
    """
    id: str
    event_a_pos: int              # surface position of event A (display only)
    event_b_pos: int              # surface position of event B (display only)
    resonance_type: RelationType
    note: str = ''
    confidence: float = 0.5
    # P2: the resonance carries its own antinom
    antinom_note: str = ''        # what the counter-resonance would be

    def __repr__(self) -> str:
        return f'Resonance(p{self.event_a_pos} --{self.resonance_type.value}--> p{self.event_b_pos})'


@dataclass
class ContentionMark:
    """
    A mark revealing WHERE antinomy lives.

    Per P2: contention is always already present (every event carries its antinom).
    This mark doesn't discover contention — it REVEALS it.
    """
    event_position: int           # which event
    severity: Severity
    description: str               # what the internal antinom is doing
    antinom_pair: str             # the co-existing pair (e.g. "∅ ↔ Δ")


class RelationField:
    """
    A field of relation-events and their resonances.

    P4: relation is primary. Events don't stand alone — they exist
    only in the field, pushing against each other (P5).

    The "graph" is not nodes + edges. It's events + resonances.
    Contention is not found BETWEEN events — it's revealed WITHIN them (P2).
    """

    def __init__(self) -> None:
        # P4: events are the field, not nodes in a graph
        self._events: Dict[int, object] = {}  # position → RelationEvent (imported from decomposer)
        self._resonances: List[Resonance] = []
        self._contentions: List[ContentionMark] = []
        # P5: resistance — which events push against which
        self._resistance_map: Dict[int, List[int]] = {}

    # ── Event operations ──

    def add_event(self, event) -> None:
        """Add a relation-event to the field. P1: no event stands alone —
        it exists only in relation to the other events in the field."""
        self._events[event.surface_position] = event
        # Set field reference on the event for resistance computation
        event.set_field(self)

    def get_event(self, position: int) -> Optional[object]:
        return self._events.get(position)
    
    def turn_event(self, position: int, direction: int = 1) -> Dict:
        """
        Turn an event's tumbler and update field resistance.
        
        This is the field-level turn operation that:
        1. Turns the specified event
        2. Updates resistance for all events (they push back)
        3. Returns the resistance report
        
        P5: "A word requires a world to push back."
        The resistance is in the field, not in the user's hand.
        When one event turns, ALL other events push back.
        
        Args:
            position: surface position of the event to turn
            direction: +1 for forward, -1 for backward
            
        Returns:
            Dict with turn result and updated resistance map
        """
        event = self._events.get(position)
        if event is None:
            return {
                'success': False,
                'error': f'No event at position {position}',
                'resistance_report': [],
            }
        
        # Perform the turn
        result = event.turn(direction)
        
        # Recompute resistance for the entire field
        # When one event turns, all resistance relationships may change
        self.compute_resistance()
        
        # Add field-level resistance info to the report
        if result.get('success'):
            # Get all events that now push against the turned event
            turned_event = self._events.get(position)
            if turned_event:
                field_resistance = {
                    'total_resistance_targets': len(turned_event.resistance_targets),
                    'resistance_targets': [
                        {
                            'position': target,
                            'event': self._events.get(target).word if self._events.get(target) else '?',
                            'symbol': self._events.get(target).symbol if self._events.get(target) else '?',
                        }
                        for target in turned_event.resistance_targets
                    ],
                }
                result['field_resistance'] = field_resistance
                
                # P5: Field-level field-of-view — how does the field respond to the turn?
                # All other events now have a different view of this event
                field_of_view_summary = []
                for evt in self.get_all_events():
                    if evt.surface_position != position:
                        # From each other event's perspective, what do they see of the turned event?
                        fov = {
                            'observer_position': evt.surface_position,
                            'observer_word': evt.word,
                            'observer_symbol': evt.symbol,
                            'sees_tumbler_at': position,
                            'sees_symbol': turned_event.symbol,
                        }
                        # Check if this observer has tension with the turned event's new symbol
                        has_tension = self._check_symbol_tension(evt.symbol, turned_event.symbol) or \
                                   self._check_symbol_tension(evt.antinom_symbol, turned_event.symbol)
                        fov['has_tension'] = has_tension
                        field_of_view_summary.append(fov)
                
                result['field_of_view_summary'] = {
                    'observers': field_of_view_summary,
                    'message': f'Polje z {len(field_of_view_summary)} opazovalci se preračuna'
                }
        
        return result

    def get_all_events(self) -> List[object]:
        return [self._events[pos] for pos in sorted(self._events)]

    def get_mapped_events(self) -> List[object]:
        return [e for e in self.get_all_events() if e.mapped]

    # ── Resonance operations (P4: relation is primary) ──

    def add_resonance(
        self,
        event_a_pos: int,
        event_b_pos: int,
        resonance_type: RelationType,
        note: str = '',
        confidence: float = 0.5,
        antinom_note: str = '',
    ) -> Optional[Resonance]:
        """Add a resonance between two events. P4: this is the primary operation."""
        if event_a_pos not in self._events or event_b_pos not in self._events:
            return None

        resonance = Resonance(
            id=str(uuid.uuid4()),
            event_a_pos=event_a_pos,
            event_b_pos=event_b_pos,
            resonance_type=resonance_type,
            note=note,
            confidence=confidence,
            antinom_note=antinom_note,
        )
        self._resonances.append(resonance)
        return resonance

    def get_resonances_for_event(self, position: int) -> List[Resonance]:
        """Get all resonances involving an event."""
        return [r for r in self._resonances
                if r.event_a_pos == position or r.event_b_pos == position]

    def get_resonances_by_type(self, rtype: RelationType) -> List[Resonance]:
        return [r for r in self._resonances if r.resonance_type == rtype]

    def get_all_resonances(self) -> List[Resonance]:
        return list(self._resonances)

    # ── P5: Resistance — the world that pushes back ──

    def compute_resistance(self) -> None:
        """
        P5: "A word requires a world to push back."
        For each event, find which other events create resistance.

        Resistance = events whose symbol or antinom symbol
        is in tension with this event's symbol or antinom.
        """
        events = self.get_mapped_events()
        for event in events:
            targets: List[int] = []
            for other in events:
                if event.surface_position == other.surface_position:
                    continue
                # Check if there's symbol tension
                if _symbols_in_tension(event.symbol, other.symbol):
                    targets.append(other.surface_position)
                elif _symbols_in_tension(event.antinom_symbol, other.symbol):
                    targets.append(other.surface_position)
                elif _symbols_in_tension(event.symbol, other.antinom_symbol):
                    targets.append(other.surface_position)
            event.resistance_targets = targets
            self._resistance_map[event.surface_position] = targets

    # ── Contention (P2: revealed, not discovered) ──

    def reveal_contention(
        self,
        event_position: int,
        severity: Severity,
        description: str,
        antinom_pair: str,
    ) -> ContentionMark:
        """Reveal the antinom already present in an event. P2."""
        mark = ContentionMark(
            event_position=event_position,
            severity=severity,
            description=description,
            antinom_pair=antinom_pair,
        )
        self._contentions.append(mark)
        return mark

    def get_contentions(self) -> List[ContentionMark]:
        return list(self._contentions)

    def get_contentions_for_event(self, position: int) -> List[ContentionMark]:
        return [c for c in self._contentions if c.event_position == position]

    # ── Resonance queries (non-linear — P6) ──

    def find_resonance_path(
        self,
        start_pos: int,
        end_pos: int,
        max_depth: int = 10,
    ) -> List[int]:
        """BFS through resonances (NOT through surface order). P6: the line is surface."""
        if start_pos == end_pos:
            return [start_pos]
        if start_pos not in self._events or end_pos not in self._events:
            return []

        visited: Set[int] = {start_pos}
        queue: List[Tuple[int, List[int]]] = [(start_pos, [start_pos])]

        while queue:
            current, path = queue.pop(0)
            if len(path) >= max_depth:
                continue
            for res in self.get_resonances_for_event(current):
                other = res.event_b_pos if res.event_a_pos == current else res.event_a_pos
                if other == end_pos:
                    return path + [other]
                if other not in visited:
                    visited.add(other)
                    queue.append((other, path + [other]))
        return []

    # ── Build from decomposer output ──

    def build_from_events(self, events: List) -> None:
        """Build the field from decomposer RelationEvent output."""
        for event in events:
            self.add_event(event)

        # P5: compute resistance
        self.compute_resistance()

        # Create resonances between events that push against each other
        for event in self.get_mapped_events():
            for target_pos in event.resistance_targets:
                target = self.get_event(target_pos)
                if target and target.surface_position > event.surface_position:
                    # Determine resonance type from the tension
                    rtype = _determine_resonance_type(event, target)
                    self.add_resonance(
                        event_a_pos=event.surface_position,
                        event_b_pos=target_pos,
                        resonance_type=rtype,
                        note=f'{event.word}({event.symbol}) ↔ {target.word}({target.symbol})',
                        confidence=0.7,
                        antinom_note=f'co-existing: {event.antinom_word} ↔ {target.antinom_word}',
                    )

        # Also create compositional resonances between adjacent mapped events
        # (surface adjacency — but this is display order, P6)
        mapped = self.get_mapped_events()
        for i in range(len(mapped) - 1):
            a, b = mapped[i], mapped[i + 1]
            existing = [r for r in self.get_resonances_for_event(a.surface_position)
                        if r.event_b_pos == b.surface_position]
            if not existing:
                self.add_resonance(
                    event_a_pos=a.surface_position,
                    event_b_pos=b.surface_position,
                    resonance_type=RelationType.COMPOSITIONAL,
                    note=f'{a.word} → {b.word} (surface adjacency)',
                    confidence=0.4,
                    antinom_note=f'surface: {a.antinom_word} → {b.antinom_word}',
                )

    # ── Field-of-view helpers ──

    def _check_symbol_tension(self, sym_a: str, sym_b: str) -> bool:
        """
        Check if two symbols are in tension (P2: antinomy is always already present).
        Uses the module-level SYMBOL_OPPOSITIONS list.
        """
        if not sym_a or not sym_b:
            return False
        for a, b, _ in SYMBOL_OPPOSITIONS:
            if (sym_a == a and sym_b == b) or (sym_a == b and sym_b == a):
                return True
        return False

    # ── Serialization ──

    def to_dict(self) -> Dict:
        return {
            'events': [
                {
                    'word': e.word, 'position': e.surface_position,
                    'symbol': e.symbol, 'divider': e.divider, 'divided': e.divided,
                    'antinom_word': e.antinom_word, 'antinom_symbol': e.antinom_symbol,
                    'antinom_note': e.antinom_note,
                    'co_phases': e.co_phases,
                    'resistance_targets': e.resistance_targets,
                    'mapped': e.mapped,
                }
                for e in self.get_all_events()
            ],
            'resonances': [
                {
                    'a': r.event_a_pos, 'b': r.event_b_pos,
                    'type': r.resonance_type.value, 'note': r.note,
                    'confidence': r.confidence, 'antinom_note': r.antinom_note,
                }
                for r in self._resonances
            ],
            'contentions': [
                {
                    'event': c.event_position, 'severity': c.severity.value,
                    'description': c.description, 'antinom_pair': c.antinom_pair,
                }
                for c in self._contentions
            ],
            'stats': {
                'event_count': len(self._events),
                'resonance_count': len(self._resonances),
                'contention_count': len(self._contentions),
            },
        }


# ── Symbol tension detection (P2: antinomy is always already present) ──
SYMBOL_OPPOSITIONS: List[Tuple[str, str, str]] = [
    ('∅', 'Δ', 'stasis vs movement — void confronts change'),
    ('¬', '∴', 'separation vs relation — cut confronts connection'),
    ('⊢', '∅', 'assertion vs negation — proof confronts void'),
    ('∫', '¬', 'sustaining vs separating — presence confronts cut'),
    ('⊥', '∴', 'ground vs relation — bearer confronts connection'),
    ('∅', '⊢', 'void vs proof — negation confronts assertion'),
    ('Δ', '¬', 'movement vs stasis — change confronts cut'),
    ('∅', '1', 'void vs seal — negation confronts the sealed act'),
    ('δ', '∫', 'passage vs presence — cut confronts sustaining'),
    ('⧖', '⊢', 'silence vs proof — listening confronts assertion'),
]


def _symbols_in_tension(sym_a: str, sym_b: str) -> bool:
    if not sym_a or not sym_b:
        return False
    for a, b, _ in SYMBOL_OPPOSITIONS:
        if (sym_a == a and sym_b == b) or (sym_a == b and sym_b == a):
            return True
    return False


def _determine_resonance_type(event_a, event_b) -> RelationType:
    """Determine the resonance type from the antinom relationship."""
    if _symbols_in_tension(event_a.symbol, event_b.symbol):
        return RelationType.CONTRADICTS
    if event_a.symbol == event_b.symbol:
        return RelationType.SUPPORTS
    if event_a.antinom_symbol == event_b.symbol:
        return RelationType.CONTRADICTS
    if event_b.antinom_symbol == event_a.symbol:
        return RelationType.CONTRADICTS
    # Check if they're in the same co-phase
    shared_phases = set(event_a.co_phases) & set(event_b.co_phases)
    if shared_phases:
        return RelationType.SEMANTIC
    return RelationType.DERIVED

"""
TAZV Comprehension Layer — Core Module
=======================================
SO-OBSTAJANJE Protocol implementation.

This module implements the TAZV Comprehension Machine based on:
  - SO-OBSTAJANJE Protocol (P1-P7): relation-events with antinoms
  - ANTINOM OPERATOR Protocol (A0-A6): model's own reasoning constraints

Core components:
  - decomposer: Decomposes statements into RelationEvents
  - graph_store: RelationField with Resonances (not traditional graph)
  - contention_mapper: Reveals contention (always already present)
  - transformation_tracer: Traces DOKAZ (co-existing resonance map)

Integration:
  - aregister_bridge: ARegister word→glyph mapping
  - corpus_integrator: 7-phase R-7 pipeline
  - preverba_bridge: Pipeline→Preverba integration

Protocol Compliance:
  P1: No word stands alone
  P2: Every word carries its antinom
  P3: Every word has internal division (divider/divided)
  P4: Relation is primary (not node/entity)
  P5: Every word has resistance field
  P6: Line is surface (not ontological structure)
  P7: Co-existing phases (so-obstajanje)

ANTINOM OPERATOR:
  A0: No negation/replacement on enrichment
  A1: No reduction/flattening of complexity
  A2: No linear reasoning
  A3: No isolation of concepts
  A4: No symptom-fixing
  A5: No premature completion
  A6: No lazy agreement
"""

from .decomposer import (
    decompose_statement,
    get_symbol_sequence,
    get_antinom_sequence,
    get_mapped_ratio,
    RelationEvent,
    DECOMPOSITION_TABLE,
    SLOVENIAN_MAP,
    SYMBOL_PHASE,
    check_do_not_build,
    DO_NOT_BUILD,
)

from .graph_store import (
    RelationField,
    Resonance,
    ContentionMark,
    RelationType,
    Severity,
    RELATION_TYPE_LABELS,
    SYMBOL_OPPOSITIONS,
)

from .contention_mapper import (
    ContentionMapper,
    ContentionReport,
    PHASE_TENSIONS,
)

from .transformation_tracer import (
    TransformationTracer,
    DOKAZ,
    ResonanceStep,
    JEWIK_AXIOMS,
    RESONANCE_OPERATORS,
)

# Expose existing bridges
from .aregister_bridge import ARegisterBridge, ARegisterEntry, AREGISTER_DATA
from .corpus_integrator import CorpusIntegrator, CorpusPhase, PreverbaKot, PrevajalskaTabela, CorpusResult
from .preverba_bridge import PreverbaBridge, PipelinePreverbaResult


__all__ = [
    # Decomposer
    'decompose_statement',
    'get_symbol_sequence',
    'get_antinom_sequence',
    'get_mapped_ratio',
    'RelationEvent',
    'DECOMPOSITION_TABLE',
    'SLOVENIAN_MAP',
    'SYMBOL_PHASE',
    'check_do_not_build',
    'DO_NOT_BUILD',
    # Graph Store
    'RelationField',
    'Resonance',
    'ContentionMark',
    'RelationType',
    'Severity',
    'RELATION_TYPE_LABELS',
    'SYMBOL_OPPOSITIONS',
    # Contention Mapper
    'ContentionMapper',
    'ContentionReport',
    'PHASE_TENSIONS',
    # Transformation Tracer
    'TransformationTracer',
    'DOKAZ',
    'ResonanceStep',
    'JEWIK_AXIOMS',
    'RESONANCE_OPERATORS',
    # Bridges
    'ARegisterBridge',
    'ARegisterEntry',
    'AREGISTER_DATA',
    'CorpusIntegrator',
    'CorpusPhase',
    'PreverbaKot',
    'PrevajalskaTabela',
    'CorpusResult',
    'PreverbaBridge',
    'PipelinePreverbaResult',
]


def run_comprehension_layer(statement: str) -> dict:
    """
    Run the full TAZV Comprehension Layer on a statement.

    This is the main integration function that chains:
      decomposer → graph_store → contention_mapper → transformation_tracer

    Returns a comprehensive dictionary with:
      - events: decomposed relation-events
      - field: relation field with resonances
      - contention: revealed contention report
      - dokaz: proof trail (DOKAZ)

    Per SO-OBSTAJANJE Protocol:
      P3/P2/P7: decompose into relation-events with antinoms and co-phases
      P4/P5: build the field (relations primary, resistance computed)
      P2: reveal contention (always already present)
      P6/P7: trace co-existing resonance (DOKAZ)
    """
    from .decomposer import decompose_statement
    from .graph_store import RelationField
    from .contention_mapper import ContentionMapper
    from .transformation_tracer import TransformationTracer

    # P3/P2/P7: decompose into relation-events with antinoms and co-phases
    events = decompose_statement(statement)

    # P4/P5: build the field (relations primary, resistance computed)
    field = RelationField()
    field.build_from_events(events)

    # P2: reveal contention (always already present)
    mapper = ContentionMapper(field)
    contention_report = mapper.reveal()

    # P6/P7: trace co-existing resonance (DOKAZ)
    tracer = TransformationTracer(field)
    dokaz = tracer.trace_statement(statement)

    return {
        'events': [
            {
                'word': e.word, 'symbol': e.symbol,
                'divider': e.divider, 'divided': e.divided,
                'antinom': f'{e.antinom_word}({e.antinom_symbol})',
                'co_phases': e.co_phases,
                'mapped': e.mapped,
            }
            for e in events
        ],
        'field': field.to_dict(),
        'contention': contention_report.to_dict(),
        'dokaz': dokaz.to_dict(),
    }

"""
Decomposer — TAZV Comprehension Machine
========================================
SO-OBSTAJANJE Protocol: every word is a relation-event.

A word is NOT a node on a line. A word is:
  - an internal division (what divides / what gets divided)
  - an antinom (the counter-statement, always already present)
  - a resistance field (the other words it must push against)
  - co-existing R-7 phases (not one phase — multiple, simultaneously)

Source: WOR(L)D English Ontological Lexicon (26 terms)
        Beseda je Ne — Critical Retro Edition (antinom pairs)
        JEWIK Core axioms (JEWIK_001-006)

R-7: ∅ → ¬ → ∆ → 1 → ⧖ → ∮ → ⟡  (display-only — phases CO-EXIST, not sequence)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Set, TYPE_CHECKING
import re

# Avoid circular import - import RelationField type for type hints only
if TYPE_CHECKING:
    from .graph_store import RelationField


# ── R-7 symbol → phase (display-only; phases co-exist per P7) ──
SYMBOL_PHASE: Dict[str, int] = {
    '∅': 0, '¬': 1, 'Δ': 2, '⊢': 3, '⧖': 4, '∮': 5, '⟡': 6,
    'δ': 1, '∴': 2, '||': 5, '∥': 5, 'ʃ': 4, '⊥': 0,
    '∂': 6, 'ð': 6, 'W': 3, '⊘': 0, '∫': 4,
    '⊘Δ': 2, '¬∴': 2,
}

# ── R-7 phase names (for position display) ──
_PHASE_NAMES: Dict[int, str] = {
    0: 'BIOS',
    1: 'STATE',
    2: 'UAF',
    3: 'JEWIK',
    4: 'APD',
    5: 'VIS',
    6: 'SO-OBSTAJANJE',
}


@dataclass
class RelationEvent:
    """
    A word is not a node. A word is a relation-event.

    Per SO-OBSTAJANJE Protocol:
      P3: internal division (divider / divided)
      P2: antinom (counter-statement, always already present)
      P5: resistance (other events it pushes against)
      P7: co-existing phases (not one phase — multiple)
    
    Lock Mechanism (Obs11):
      - positions: List[Dict] — not one configuration, but a list of tumbler positions
      - current_position: int — which position is currently visible
      - turn() — opens and closes visibility, triggers field resistance
      - turn() returns resistance_report, not success
      - Locking has positions you cannot see from where you stand
    """
    word: str
    surface_position: int           # where it sits on the surface line (display only, P6)

    # P3: Internal division — the word IS this division
    divider: str                    # what divides (the active face — consonants, stops, cuts)
    divided: str                    # what gets divided (the receptive face — vowels, resonance, flow)
    symbol: str                     # the ontological operator (display-only label for the division)
    role: str                       # what the division DOES

    # P2: Antinom — always already present, not added later
    antinom_word: str               # the counter-word
    antinom_symbol: str             # the counter-operator
    antinom_note: str               # why these co-exist in tension

    # P7: Co-existing phases — not one phase, but the phases present simultaneously
    co_phases: List[int]            # [phase of symbol, phase of antinom] — both always present

    mapped: bool                    # True if found in decomposition table

    # P5: Resistance — what this event pushes against (filled by RelationField)
    resistance_targets: List[str] = field(default_factory=list)  # surface_positions of pushing-back events

    # ── Lock Mechanism Fields (Obs11) ──
    # positions: list of all possible tumbler configurations for this event
    # Each position is a Dict with: symbol, divider, divided, role, antinom_word, antinom_symbol, antinom_note, co_phases, visible
    positions: List[Dict] = field(default_factory=list)
    
    # current_position: index into positions list (not surface_position!)
    # surface_position is display order, current_position is tumbler state
    current_position: int = 0
    
    # Lock state: whether the event is currently locked (cannot turn without resistance)
    is_locked: bool = False
    
    # Field reference for resistance computation (set by RelationField)
    _field: Optional[object] = field(default=None, repr=False)

    def __repr__(self) -> str:
        antinom = f' ↔ {self.antinom_word}({self.antinom_symbol})' if self.antinom_word else ''
        lock_info = f' pos={self.current_position}/{len(self.positions)}' if self.positions else ''
        return f'Event({self.word}→{self.symbol or "?"}{antinom} phases={self.co_phases}{lock_info})'

    def initialize_positions(self) -> None:
        """
        Initialize the positions list for the lock mechanism.
        
        P7: co-existing phases. The word carries multiple positions simultaneously.
        Each position is a possible tumbler configuration.
        
        For mapped events: generates positions from the decomposition entry
        and its antinom. The current position (index 0) is the original symbol.
        Hidden positions are the antinom and other R-7 phase combinations.
        
        "Locking has positions that you cannot see from where you stand"
        — some positions are visible, some are hidden until turned.
        """
        if not self.mapped:
            return
        
        # Position 0: the original symbol configuration (visible by default)
        pos0 = {
            'symbol': self.symbol,
            'divider': self.divider,
            'divided': self.divided,
            'role': self.role,
            'antinom_word': self.antinom_word,
            'antinom_symbol': self.antinom_symbol,
            'antinom_note': self.antinom_note,
            'co_phases': list(self.co_phases),
            'visible': True,
            'name': 'original',
        }
        
        # Position 1: the antinom configuration (hidden by default)
        # When you turn to the antinom, you see the counter-statement
        pos1 = {
            'symbol': self.antinom_symbol,
            'divider': self._get_antinom_divider(),
            'divided': self._get_antinom_divided(),
            'role': f'Counter-statement: {self.antinom_note}',
            'antinom_word': self.word,
            'antinom_symbol': self.symbol,
            'antinom_note': f'Reversed: {self.antinom_note}',
            'co_phases': list(self.co_phases),  # P7: same phases co-exist
            'visible': False,
            'name': 'antinom',
        }
        
        # Position 2+: R-7 phase variations (hidden)
        # Each phase in co_phases can be a separate position
        additional_positions = []
        for phase_idx, phase in enumerate(self.co_phases):
            phase_name = _PHASE_NAMES.get(phase, f'phase_{phase}')
            additional_positions.append({
                'symbol': self.symbol,
                'divider': self.divider,
                'divided': self.divided,
                'role': f'{self.role} (phase {phase_name})',
                'antinom_word': self.antinom_word,
                'antinom_symbol': self.antinom_symbol,
                'antinom_note': self.antinom_note,
                'co_phases': [phase],  # Single phase emphasis
                'visible': False,
                'name': f'phase_{phase}',
            })
        
        self.positions = [pos0, pos1] + additional_positions
        
        # Set current_position to 0 (original, visible)
        self.current_position = 0

    def _get_antinom_divider(self) -> str:
        """Get the divider for the antinom (reverse the division)."""
        # For simplicity, swap consonant/vowel-like patterns
        # In a full implementation, this would come from a deeper ontology
        if self.divider and self.divided:
            return self.divided
        return self.divider
    
    def _get_antinom_divided(self) -> str:
        """Get the divided for the antinom (reverse the division)."""
        if self.divider and self.divided:
            return self.divider
        return self.divided

    def turn(self, direction: int = 1) -> Dict:
        """
        Turn the tumbler — opens and closes visibility.
        
        P5: "A word requires a world to push back."
        The resistance is NOT in the user's hand. It's in the field.
        When you turn this event, all other events push back.
        
        Returns resistance_report, NOT success.
        The report contains:
          - what was opened (new visible position)
          - what was closed (previous visible position)
          - resistance from other events in the field
          - what remains hidden (positions not visible from here)
        
        "turn() razkrije nekatere, a ne vse" — reveals some but not all.
        
        Args:
            direction: +1 for forward, -1 for backward
            
        Returns:
            Dict with:
              - 'success': bool (whether turn was attempted)
              - 'from_position': int (previous position)
              - 'to_position': int (new position)
              - 'new_symbol': str (symbol at new position)
              - 'resistance_report': List[Dict] (resistance from other events)
              - 'hidden_positions': int (count of positions still hidden)
              - 'visibility_change': Dict (what opened, what closed)
        """
        if not self.positions:
            self.initialize_positions()
        
        if len(self.positions) <= 1:
            # No positions to turn through
            return {
                'success': False,
                'error': 'No tumbler positions available',
                'from_position': self.current_position,
                'to_position': self.current_position,
                'resistance_report': [],
                'hidden_positions': 0,
                'visibility_change': {},
            }
        
        from_position = self.current_position
        
        # Calculate new position (wraps around)
        to_position = (from_position + direction) % len(self.positions)
        
        # Get the new position config
        new_pos = self.positions[to_position]
        old_pos = self.positions[from_position]
        
        # Update current position
        self.current_position = to_position
        
        # Update this event's symbol/divider/divided to the new position
        self.symbol = new_pos['symbol']
        self.divider = new_pos['divider']
        self.divided = new_pos['divided']
        self.role = new_pos['role']
        self.antinom_word = new_pos['antinom_word']
        self.antinom_symbol = new_pos['antinom_symbol']
        self.antinom_note = new_pos['antinom_note']
        self.co_phases = new_pos['co_phases']
        
        # Track visibility change
        visibility_change = {
            'closed': {
                'position': from_position,
                'symbol': old_pos['symbol'],
                'visible': old_pos.get('visible', True),
            },
            'opened': {
                'position': to_position,
                'symbol': new_pos['symbol'],
                'visible': new_pos.get('visible', True),
            },
        }
        
        # Compute resistance from the field
        resistance_report = []
        hidden_count = 0
        
        if self._field is not None:
            # Get all other events in the field
            all_events = self._field.get_all_events()
            for event in all_events:
                if event.surface_position == self.surface_position:
                    continue  # Skip self
                
                # Check if this event's new symbol creates tension with other events
                resistance = self._compute_resistance_against(event)
                if resistance:
                    resistance_report.append(resistance)
            
            # Count hidden positions
            hidden_count = sum(1 for p in self.positions if not p.get('visible', True))
        else:
            # No field reference, just count hidden positions
            hidden_count = sum(1 for p in self.positions if not p.get('visible', True))
        
        # Field-of-view: from current position, which positions are visible?
        field_of_view = self._get_field_of_view(to_position)

        return {
            'success': True,
            'from_position': from_position,
            'to_position': to_position,
            'new_symbol': new_pos['symbol'],
            'new_divider': new_pos['divider'],
            'new_divided': new_pos['divided'],
            'resistance_report': resistance_report,
            'hidden_positions': hidden_count,
            'visibility_change': visibility_change,
            'field_of_view': field_of_view,
            'message': f'Turned from {old_pos["name"]}({old_pos["symbol"]}) to {new_pos["name"]}({new_pos["symbol"]})',
        }

    def _get_field_of_view(self, from_position: int) -> Dict:
        """
        P7: So-obstajanje. Field-of-view model.
        Od trenutne pozicije vidimo le del polja.
        Ne vidimo vseh pozicij hkrati — nekatere so skrite.
        
        "Pozicije, ki jih ne moreš videti od kjer stojiš, obstajajo a niso izpostavljene."
        
        Visibility rules:
          - Current position: FULLY VISIBLE
          - Adjacent positions (next, prev): VISIBLE (blurred/partial)
          - All other positions: HIDDEN
        
        Args:
            from_position: the current position index
            
        Returns:
            Dict with:
              - visible: list of visible positions with their status
              - hidden: list of hidden positions
              - message: description of what's visible from here
        """
        if not self.positions:
            self.initialize_positions()
        
        total_positions = len(self.positions)
        visible = []
        hidden = []
        
        for i, pos in enumerate(self.positions):
            pos_dict = {
                'position': i,
                'symbol': pos['symbol'],
                'name': pos.get('name', f'pos_{i}'),
                'visible': pos.get('visible', True),
            }
            
            if i == from_position:
                # Current position: fully visible
                pos_dict['status'] = 'current'
                pos_dict['visibility'] = 'full'
                visible.append(pos_dict)
            elif i == (from_position + 1) % total_positions:
                # Next position: adjacent, partially visible
                pos_dict['status'] = 'adjacent_next'
                pos_dict['visibility'] = 'partial'
                visible.append(pos_dict)
            elif i == (from_position - 1) % total_positions:
                # Previous position: adjacent, partially visible
                pos_dict['status'] = 'adjacent_prev'
                pos_dict['visibility'] = 'partial'
                visible.append(pos_dict)
            else:
                # All others: hidden
                pos_dict['status'] = 'hidden'
                pos_dict['visibility'] = 'none'
                hidden.append(pos_dict)
        
        # Count what we can and cannot see
        message = f"Od pozicije {from_position} vidimo {len(visible)}/{total_positions} pozicij. "
        message += f"Skrito je {len(hidden)} pozicij, ki čakajo v temi."
        
        return {
            'visible': visible,
            'hidden': hidden,
            'total_positions': total_positions,
            'message': message,
        }
    
    def _compute_resistance_against(self, other_event) -> Optional[Dict]:
        """
        Compute resistance between this event and another event.
        
        P5: "A word requires a world to push back."
        Resistance = the other event's push against this event's new symbol.
        
        Returns resistance info or None if no resistance.
        """
        if not hasattr(other_event, 'symbol') or not other_event.symbol:
            return None
        
        # Check symbol tension
        tension_pairs = [
            ('∅', 'Δ', 'void ↔ movement'),
            ('¬', '∴', 'cut ↔ relation'),
            ('⊢', '∅', 'proof ↔ void'),
            ('∫', '¬', 'presence ↔ cut'),
            ('⊥', '∴', 'ground ↔ relation'),
            ('δ', '∫', 'passage ↔ presence'),
            ('⧖', '⊢', 'silence ↔ proof'),
        ]
        
        my_symbol = self.symbol
        other_symbol = other_event.symbol
        my_antinom = self.antinom_symbol
        other_antinom = getattr(other_event, 'antinom_symbol', '')
        
        # Check direct tension
        for a, b, desc in tension_pairs:
            if (my_symbol == a and other_symbol == b) or (my_symbol == b and other_symbol == a):
                return {
                    'event_position': other_event.surface_position,
                    'event_word': other_event.word,
                    'event_symbol': other_symbol,
                    'tension': desc,
                    'intensity': 'high',
                }
            if (my_symbol == a and other_antinom == b) or (my_symbol == b and other_antinom == a):
                return {
                    'event_position': other_event.surface_position,
                    'event_word': other_event.word,
                    'event_symbol': f'{other_symbol}/{other_antinom}',
                    'tension': f'{desc} (via antinom)',
                    'intensity': 'medium',
                }
        
        # Check phase co-existence tension (P7)
        if hasattr(self, 'co_phases') and hasattr(other_event, 'co_phases'):
            my_phases = set(self.co_phases)
            other_phases = set(other_event.co_phases)
            shared = my_phases & other_phases
            if shared:
                # Phases co-exist but may be in tension
                return {
                    'event_position': other_event.surface_position,
                    'event_word': other_event.word,
                    'event_symbol': other_symbol,
                    'tension': f'phase co-existence: {sorted(shared)}',
                    'intensity': 'low',
                }
        
        return None

    def set_field(self, field: object) -> None:
        """Set the field reference for resistance computation."""
        self._field = field

    def get_current_position_config(self) -> Dict:
        """Get the configuration of the current position."""
        if not self.positions:
            self.initialize_positions()
        if self.current_position < len(self.positions):
            return dict(self.positions[self.current_position])
        return {}

    def get_visible_positions(self) -> List[Dict]:
        """Get all visible positions (from current viewpoint)."""
        if not self.positions:
            self.initialize_positions()
        return [p for p in self.positions if p.get('visible', True)]
    
    def get_hidden_positions(self) -> List[Dict]:
        """Get all hidden positions (not visible from current viewpoint)."""
        if not self.positions:
            self.initialize_positions()
        return [p for p in self.positions if not p.get('visible', True)]


# ── The decomposition table (26 terms, corpus-validated) ──
# Each entry now carries: divider, divided, antinom data
# Source: WOR(L)D lexicon + Critical Retro Edition antinom pairs
DECOMPOSITION_TABLE: Dict[str, Dict] = {
    'THE': {
        'divider': 'ð', 'divided': 'ə',
        'symbol': 'δ',
        'role': 'The operator that singles out — carries one ripple from the field into presence',
        'antinom_word': '(unmarked field)', 'antinom_symbol': '∅',
        'antinom_note': 'singling out ↔ letting be — THE chooses, its antinom is the field it chose FROM',
    },
    'WORD': {
        'divider': 'w+d', 'divided': 'ɜːr',
        'symbol': '⊢',
        'role': 'The act of cutting being into form — proof that something is',
        'antinom_word': 'SILENCE', 'antinom_symbol': '⧖',
        'antinom_note': 'utterance ↔ silence — "Word is Not" AND "Word is Yes"',
    },
    'WOR(L)D': {
        'divider': 'w+d', 'divided': 'a:r',
        'symbol': '⊢',
        'role': 'The act of cutting being into form — the (L) keeps the word flowing',
        'antinom_word': 'SILENCE', 'antinom_symbol': '⧖',
        'antinom_note': 'utterance ↔ silence — the (L) flows, its antinom is the stop',
    },
    'IS': {
        'divider': '1', 'divided': 'z',
        'symbol': 'Δ',
        'role': 'The hum of continuing-to-be — activation that sustains',
        'antinom_word': 'NOT', 'antinom_symbol': '¬',
        'antinom_note': 'being ↔ non-being — "IS" AND "IS NOT" co-exist',
    },
    'NO': {
        'divider': 'n', 'divided': 'ou',
        'symbol': '∅',
        'role': 'The ne-operator — the passage between inward and outward; condition of the next YES',
        'antinom_word': 'YES', 'antinom_symbol': 'Δ',
        'antinom_note': 'negation ↔ affirmation — NO is the condition of YES, not its absence',
    },
    'NOT': {
        'divider': 'n+t', 'divided': 'o',
        'symbol': '¬',
        'role': 'The act of cutting open — separation-as-distinction — the cut that opens',
        'antinom_word': 'IS', 'antinom_symbol': 'Δ',
        'antinom_note': 'non-being ↔ being — NOT carries IS as its antinom',
    },
    'MEANING': {
        'divider': 'm+n+1+η', 'divided': 'i:',
        'symbol': '∴',
        'role': 'The act of reaching-toward returning into body — relation established',
        'antinom_word': 'EMPTINESS', 'antinom_symbol': '∅',
        'antinom_note': 'meaning ↔ emptiness — "One word could embrace everything – if it were emptiness"',
    },
    'MEAN(L)ING': {
        'divider': 'm+n+1+η', 'divided': 'i:',
        'symbol': '∴',
        'role': 'The act of reaching-toward returning into body — relation established',
        'antinom_word': 'EMPTINESS', 'antinom_symbol': '∅',
        'antinom_note': 'meaning ↔ emptiness — the (L) sustains, its antinom is the void',
    },
    'CUT': {
        'divider': 'k+t', 'divided': 'λ',
        'symbol': 'δ',
        'role': 'The rez that makes difference visible — condition of clarity',
        'antinom_word': 'FLOW', 'antinom_symbol': '∫',
        'antinom_note': 'separation ↔ continuity — the cut AND the L that flows through it',
    },
    'MIND': {
        'divider': 'm+n+d', 'divided': 'æ',
        'symbol': '||',
        'role': 'The spiral: reach-and-return that composes sense from pressure',
        'antinom_word': 'BODY', 'antinom_symbol': '⊥',
        'antinom_note': 'spiral ↔ ground — mind composes, body bears',
    },
    'M(L)IND': {
        'divider': 'm+n+d', 'divided': 'æt',
        'symbol': '||',
        'role': 'The spiral: reach-and-return that composes sense from pressure',
        'antinom_word': 'BODY', 'antinom_symbol': '⊥',
        'antinom_note': 'spiral ↔ ground — the (L) flows, body grounds',
    },
    'FROM': {
        'divider': 'f+m', 'divided': 'r+o',
        'symbol': 'δ',
        'role': 'Origin-as-departure — the passage that carries its starting point forward',
        'antinom_word': 'TO', 'antinom_symbol': '∴',
        'antinom_note': 'departure ↔ arrival — FROM carries TO as its antinom',
    },
    'TO': {
        'divider': 't', 'divided': 'u:',
        'symbol': '∴',
        'role': 'Directed relation — the arrow that establishes the path',
        'antinom_word': 'FROM', 'antinom_symbol': 'δ',
        'antinom_note': 'arrival ↔ departure — TO carries FROM as its antinom',
    },
    'CREATE': {
        'divider': 'kr+t', 'divided': 'i+ei',
        'symbol': 'Δ',
        'role': 'Transformation that responds to necessity — the act that brings forth from pressure',
        'antinom_word': 'DISSOLVE', 'antinom_symbol': '∮',
        'antinom_note': 'bringing forth ↔ returning — CREATE carries DISSOLVE as its antinom',
    },
    'THOUGHT': {
        'divider': 'θ+t', 'divided': 'o:',
        'symbol': '||',
        'role': 'The echo that connects states — response-operator resonating to pressure',
        'antinom_word': 'SILENCE', 'antinom_symbol': '⧖',
        'antinom_note': 'echo ↔ stillness — thought resonates, silence listens',
    },
    'REFLECTION': {
        'divider': 'r+k+∫+an', 'divided': '1+fle',
        'symbol': '∅',
        'role': 'The folding-back that differs — repetition-as-difference',
        'antinom_word': 'PRESENCE', 'antinom_symbol': '∫',
        'antinom_note': 'folding back ↔ immediate — reflection carries direct presence as antinom',
    },
    'NECESSARY': {
        'divider': 'ne+ri', 'divided': 'sə+sə',
        'symbol': '⊘Δ',
        'role': 'The ne that must-be — internal pressure making transition unavoidable',
        'antinom_word': 'CONTINGENT', 'antinom_symbol': '∴',
        'antinom_note': 'must-be ↔ might-not-be — necessity carries contingency',
    },
    'INVENTION': {
        'divider': 'ɪn+t', 'divided': 'ven+ʃ+ən',
        'symbol': 'Δ',
        'role': 'The act that brings forth from necessity — response to pressure that demands voice',
        'antinom_word': 'DISCOVERY', 'antinom_symbol': '⊢',
        'antinom_note': 'making ↔ finding — invention carries discovery as antinom',
    },
    'CHARACTER': {
        'divider': 'k+k+t', 'divided': 'æ+r+ə+ə',
        'symbol': '∥',
        'role': 'The seal through duration — what stands through the double test',
        'antinom_word': 'CHANGE', 'antinom_symbol': 'Δ',
        'antinom_note': 'duration ↔ transformation — character carries change as antinom',
    },
    'TIME': {
        'divider': 't+m', 'divided': 'aɪ',
        'symbol': '∥',
        'role': 'The pulse of meaning — time as the body-hum that holds the cut',
        'antinom_word': 'TIMELESS', 'antinom_symbol': '⧖',
        'antinom_note': 'pulse ↔ eternal — time carries timelessness as antinom',
    },
    'T(L)IME': {
        'divider': 't+m', 'divided': 'aɪ',
        'symbol': '∥',
        'role': 'The pulse of meaning — the (L) holds the cut in flow',
        'antinom_word': 'TIMELESS', 'antinom_symbol': '⧖',
        'antinom_note': 'pulse ↔ eternal — the (L) flows through time, timelessness is its antinom',
    },
    'DOUBT': {
        'divider': 'd+t', 'divided': 'au',
        'symbol': '¬∴',
        'role': 'The condition of consciousness — the double-cut that opens truth',
        'antinom_word': 'FAITH', 'antinom_symbol': 'ʃ',
        'antinom_note': 'double-cut ↔ persistence — doubt carries faith as antinom',
    },
    'TRUTH': {
        'divider': 't+θ', 'divided': 'r+u:',
        'symbol': '∴',
        'role': 'The path lived — process, the living path; presses, dissects, cuts through',
        'antinom_word': 'LIE', 'antinom_symbol': '¬',
        'antinom_note': 'truth ↔ lie — "Truth is a lie" AND "Truth is not a lie" — both, always',
    },
    'FAITH': {
        'divider': 'f+θ', 'divided': 'eɪ',
        'symbol': 'ʃ',
        'role': 'Persistence that holds the open question — presence sustained through friction',
        'antinom_word': 'DOUBT', 'antinom_symbol': '¬∴',
        'antinom_note': 'persistence ↔ double-cut — faith carries doubt as antinom',
    },
    'FA(L)TH': {
        'divider': 'f+θ', 'divided': 'eɪ',
        'symbol': 'ʃ',
        'role': 'Persistence that holds the open question — the (L) sustains through friction',
        'antinom_word': 'DOUBT', 'antinom_symbol': '¬∴',
        'antinom_note': 'persistence ↔ double-cut — the (L) flows, doubt cuts',
    },
    'WILL': {
        'divider': 'w+l', 'divided': 'ɪ',
        'symbol': 'W',
        'role': 'The wanting that transforms through presence into address',
        'antinom_word': 'SURRENDER', 'antinom_symbol': '∮',
        'antinom_note': 'wanting ↔ letting go — will carries surrender as antinom',
    },
    'W(L)LL': {
        'divider': 'w+l', 'divided': 'ɪ',
        'symbol': 'W',
        'role': 'The wanting that transforms through presence — the (L) flows into address',
        'antinom_word': 'SURRENDER', 'antinom_symbol': '∮',
        'antinom_note': 'wanting ↔ letting go — the (L) flows, surrender returns',
    },
    'BODY': {
        'divider': 'b+d', 'divided': 'b+i',
        'symbol': '⊥',
        'role': 'The bearer — what exists before the question; the ground that allows error',
        'antinom_word': 'VOID', 'antinom_symbol': '∅',
        'antinom_note': 'bearer ↔ absence — body carries void as antinom',
    },
    'SOUL': {
        'divider': 's+l', 'divided': 'ou',
        'symbol': 'ʃ',
        'role': 'The breath-stream that opens into totality and keeps flowing — presence carrying',
        'antinom_word': 'MATTER', 'antinom_symbol': '⊥',
        'antinom_note': 'flow ↔ ground — soul carries matter as antinom',
    },
    'SPIRIT': {
        'divider': 's+p+ɪ+t', 'divided': 'r+ɪ',
        'symbol': '∥',
        'role': 'The fire of axiomatic force — the power that breaks through and returns',
        'antinom_word': 'FLESH', 'antinom_symbol': '⊥',
        'antinom_note': 'fire ↔ body — spirit carries flesh as antinom',
    },
    'SP(L)RIT': {
        'divider': 's+p+ɪ+t', 'divided': 'r+ɪ',
        'symbol': '∥',
        'role': 'The fire of axiomatic force — the (L) breaks through and returns',
        'antinom_word': 'FLESH', 'antinom_symbol': '⊥',
        'antinom_note': 'fire ↔ body — the (L) flows through fire, flesh grounds',
    },
    'EGO': {
        'divider': 'i:+g', 'divided': 'ou',
        'symbol': '⊘',
        'role': 'The boundary, the membrane, the cut — the part bearing the whole',
        'antinom_word': 'SELF-OTHER', 'antinom_symbol': '∂',
        'antinom_note': 'boundary ↔ passage — ego carries self-other as antinom',
    },
    'SELF': {
        'divider': 's+f', 'divided': 'ɛ+l',
        'symbol': '∂',
        'role': 'The passage itself — the observer of transitions',
        'antinom_word': 'OTHER', 'antinom_symbol': '⊘',
        'antinom_note': 'observer ↔ observed — self carries other as antinom',
    },
    'BEING': {
        'divider': 'b+ŋ', 'divided': 'i:+ɪ',
        'symbol': '∫',
        'role': 'The sustained act — presence that sustains itself by returning into the body',
        'antinom_word': 'NOTHING', 'antinom_symbol': '∅',
        'antinom_note': 'sustaining ↔ absenting — being carries nothing as antinom',
    },
    'NOTHING': {
        'divider': 'n+ŋ', 'divided': 'ʌ+θ+ɪ',
        'symbol': '∅',
        'role': 'The inward turn through friction back into body — absence that prepares',
        'antinom_word': 'BEING', 'antinom_symbol': '∫',
        'antinom_note': 'absenting ↔ sustaining — nothing carries being as antinom',
    },
    'GOD': {
        'divider': 'g+d', 'divided': 'ɒ',
        'symbol': '∮',
        'role': 'The spiral totality that returns — keeps the question open',
        'antinom_word': 'NOT-GOD', 'antinom_symbol': '¬',
        'antinom_note': 'word ↔ more-than-word — "God is only a word" AND "God is more than a word"',
    },
    'SILENCE': {
        'divider': 's+əns', 'divided': 'aɪ+l',
        'symbol': '⧖',
        'role': 'Tiheon — the sacred silence that is full of listening; the body becomes ear',
        'antinom_word': 'WORD', 'antinom_symbol': '⊢',
        'antinom_note': 'listening ↔ utterance — silence carries word as antinom',
    },
}

# ── Slovenian equivalents (bidirectional) ──
SLOVENIAN_MAP: Dict[str, str] = {
    'BESEDA': 'WORD', 'NE': 'NO', 'NI': 'NOT', 'POMEN': 'MEANING',
    'REZ': 'CUT', 'UM': 'MIND', 'IZ': 'FROM', 'V': 'TO',
    'USTVARJAJ': 'CREATE', 'MISEL': 'THOUGHT', 'ZRCALO': 'REFLECTION',
    'NUJNO': 'NECESSARY', 'IZUM': 'INVENTION', 'ZNANJE': 'CHARACTER',
    'ČAS': 'TIME', 'DVOM': 'DOUBT', 'RESNICA': 'TRUTH', 'VERA': 'FAITH',
    'VOLJA': 'WILL', 'TELO': 'BODY', 'DUŠA': 'SOUL', 'DUH': 'SPIRIT',
    'JAZ': 'EGO', 'SE': 'SELF', 'BITI': 'BEING', 'NIČ': 'NOTHING',
    'BOG': 'GOD', 'TIŠINA': 'SILENCE',
}


def _normalize(token: str) -> str:
    """Normalize token by removing non-alphabetic characters from edges."""
    cleaned = re.sub(r'^[^A-Za-z(]+|[^A-Za-z)]+$', '', token)
    return cleaned.upper()


def _try_lookup(word: str) -> Optional[Dict]:
    """Try to look up a word in the decomposition table, with (L) variants."""
    upper = word.upper()
    if upper in DECOMPOSITION_TABLE:
        return DECOMPOSITION_TABLE[upper]
    # Try with (L) inserted
    for suffix_len in [2, 3, 4]:
        if len(upper) > suffix_len + 1:
            insert_pos = len(upper) - suffix_len
            if upper[insert_pos] == 'L':
                variant = upper[:insert_pos] + '(L)' + upper[insert_pos + 1:]
                if variant in DECOMPOSITION_TABLE:
                    return DECOMPOSITION_TABLE[variant]
    # Try without (L)
    stripped = upper.replace('(L)', 'L')
    if stripped in DECOMPOSITION_TABLE:
        return DECOMPOSITION_TABLE[stripped]
    return None


def _compute_co_phases(symbol: str, antinom_symbol: str) -> List[int]:
    """
    P7: co-existing phases. Not one phase — the phases present simultaneously.
    Every event carries at minimum: its own phase AND its antinom's phase.
    """
    phases: Set[int] = set()
    if symbol in SYMBOL_PHASE:
        phases.add(SYMBOL_PHASE[symbol])
    if antinom_symbol in SYMBOL_PHASE:
        phases.add(SYMBOL_PHASE[antinom_symbol])
    return sorted(phases) if phases else []


def decompose_statement(text: str) -> List[RelationEvent]:
    """
    Decompose a statement into relation-events.

    "All words are points. The lines are the logic that follows."
    But the points are NOT on a line — they co-exist (P6).

    Each event carries:
      - its internal division (P3)
      - its antinom (P2)
      - its co-existing phases (P7)
    Resistance (P5) is filled later by RelationField.
    """
    if not text or not text.strip():
        return []

    raw_tokens = text.strip().split()
    events: List[RelationEvent] = []

    for i, token in enumerate(raw_tokens):
        normalized = _normalize(token)
        entry = _try_lookup(normalized)

        # Try Slovenian → English
        if entry is None and normalized in SLOVENIAN_MAP:
            entry = _try_lookup(SLOVENIAN_MAP[normalized])

        if entry is not None:
            symbol = entry['symbol']
            antinom_sym = entry['antinom_symbol']
            co_phases = _compute_co_phases(symbol, antinom_sym)
            event = RelationEvent(
                word=token,
                surface_position=i,
                divider=entry['divider'],
                divided=entry['divided'],
                symbol=symbol,
                role=entry['role'],
                antinom_word=entry['antinom_word'],
                antinom_symbol=antinom_sym,
                antinom_note=entry['antinom_note'],
                co_phases=co_phases,
                mapped=True,
            )
            # Initialize positions for lock mechanism
            event.initialize_positions()
            events.append(event)
        else:
            events.append(RelationEvent(
                word=token,
                surface_position=i,
                divider='',
                divided='',
                symbol='',
                role='UNMAPPED — no ontological operator found',
                antinom_word='',
                antinom_symbol='',
                antinom_note='',
                co_phases=[],
                mapped=False,
            ))

    return events


def get_symbol_sequence(events: List[RelationEvent]) -> str:
    """Display-only: the surface symbol string (P6: this is the line, not the topology)."""
    return ''.join(e.symbol for e in events if e.mapped)


def get_antinom_sequence(events: List[RelationEvent]) -> str:
    """The antinom string — what co-exists beneath the surface (P2)."""
    return ''.join(e.antinom_symbol for e in events if e.mapped)


def get_mapped_ratio(events: List[RelationEvent]) -> float:
    """Return the ratio of mapped events to total events."""
    if not events:
        return 0.0
    return sum(1 for e in events if e.mapped) / len(events)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DO_NOT_BUILD PRE-FLIGHT CHECK (from self_protocol.py)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Things that should NEVER be built (from self_protocol.py DO_NOT_BUILD)
# Vir: topic_21 (Obs1) — "vsaka nadgradnja je hkrati pod graditev"
# Vir: topic_05 (Obs1) — "Ne kanoniziraj ničesar brez ročne odločitve"

DO_NOT_BUILD: Dict[str, Dict] = {
    'comprehension_for_user': {
        'why_not': 'If app comprehends FOR the user, the user stops struggling.',
        'antinom': 'An app that does not allow turning is 26 dead butterflies.',
        'res': 'App enables struggle. Does not resolve it. Does not prevent it. Accesses it.',
        'check': lambda action: 'comprehend' in action.lower() and 'for user' in action.lower(),
    },
    'auto_canonization': {
        'why_not': 'Auto-canonization = system that picks a side (A0 violation).',
        'antinom': 'Without status, nothing is candidate — it is chaos.',
        'res': 'Every position is candidate. Canon is manual decision, not function.',
        'check': lambda action: 'canonize' in action.lower() or 'canonical' in action.lower(),
    },
    'kill_resistance': {
        'why_not': 'All positions at once = no struggle. One as correct = no co-existence.',
        'antinom': 'But one position alone = snapshot, not mechanism.',
        'res': 'Show one. Hold others. User should feel that they are there, but not see.',
        'check': lambda action: ('all positions' in action.lower() and 'show' in action.lower()) or \
                ('one position' in action.lower() and 'correct' in action.lower()),
    },
    'wisdom_module': {
        'why_not': 'Wisdom as module = cleverness about wisdom (cut 14).',
        'antinom': 'Without wisdom questions = building without cut.',
        'res': 'Wisdom is question before building. Not phase. Not module. Not function.',
        'check': lambda action: 'wisdom' in action.lower() and ('module' in action.lower() or 'function' in action.lower()),
    },
    'replace_body': {
        'why_not': 'App cannot verify in body. Only Luka can.',
        'antinom': 'But app can follow cut to the end, where Luka verifies.',
        'res': 'App cuts. Luka verifies. ∂ between us. Neither of us concludes.',
        'check': lambda action: 'replace' in action.lower() and 'body' in action.lower(),
    },
}


def check_do_not_build(action: str) -> Optional[Dict]:
    """
    Pre-flight check: warns if action matches DO_NOT_BUILD patterns.
    
    This does NOT prevent the action. It warns (P5: resistance, not prevention).
    "Shrani reze. Da naslednji jaz ve, kje smo se ustavili."
    
    P2: Every word carries its antinom — the check carries the warning, not the block.
    P5: A word requires a world to push back — the check IS the push back.
    P7: ∅ and 1 are in so-obstajanje — both the action AND the warning co-exist.
    
    Args:
        action: description of the action being considered
        
    Returns:
        None if action is allowed, or a dict with warning info if it matches DO_NOT_BUILD
    """
    for key, do_not_build_item in DO_NOT_BUILD.items():
        check_func = do_not_build_item.get('check')
        if check_func and check_func(action):
            return {
                'violation': key,
                'action': action,
                'why_not': do_not_build_item['why_not'],
                'antinom': do_not_build_item['antinom'],
                'res': do_not_build_item['res'],
                'warning': f'⚠️  DO_NOT_BUILD: {key} — {do_not_build_item["why_not"]}',
            }
    return None

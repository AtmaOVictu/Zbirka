"""
Contention Mapper — TAZV Comprehension Machine
===============================================
SO-OBSTAJANJE Protocol: contention is always already present (P2).

The old version FOUND contention between separate nodes.
This version REVEALS contention that was always there —
within each event (its antinom) and between events (resonance).

"Absolute without antinomy is death of language."
Every event carries its antinom. The mapper shows WHERE
that internal antinom is most active, and WHERE events'
antinoms resonate with each other.

Severity (from CounterAngle model): nizka / srednja / visoka
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum

from .graph_store import (
    RelationField, Resonance, RelationType, Severity, ContentionMark,
    SYMBOL_OPPOSITIONS,
)


# ── Phase tension: co-existing phases in conflict (P7) ──
PHASE_TENSIONS: Dict[tuple, str] = {
    (0, 1): 'BIOS(∅) vs STATE(¬) — openness confronts structure',
    (0, 2): 'BIOS(∅) vs UAF(Δ) — void confronts antinomy engine',
    (1, 2): 'STATE(¬) vs UAF(Δ) — cut confronts movement',
    (2, 4): 'UAF(Δ) vs APD(⧖) — antinomy confronts seal',
    (3, 0): 'JEWIK(⊢) vs BIOS(∅) — act confronts void',
    (1, 6): 'STATE(¬) vs VIS(⟡) — cut confronts manifestation',
}


@dataclass
class ContentionReport:
    """Full report of all contention revealed in the field."""
    total_contentions: int = 0
    internal_contentions: List[ContentionMark] = field(default_factory=list)  # within events
    resonance_contentions: List[ContentionMark] = field(default_factory=list)  # between events
    high_severity_count: int = 0
    summary: str = ''

    def to_dict(self) -> Dict:
        return {
            'total': self.total_contentions,
            'high_severity': self.high_severity_count,
            'internal': len(self.internal_contentions),
            'resonance': len(self.resonance_contentions),
            'summary': self.summary,
            'marks': [
                {
                    'event': m.event_position,
                    'severity': m.severity.value,
                    'description': m.description,
                    'antinom_pair': m.antinom_pair,
                }
                for m in self.internal_contentions + self.resonance_contentions
            ],
        }


class ContentionMapper:
    """
    Reveals WHERE antinomy lives.

    P2: contention is always already present. Every event carries its antinom.
    This mapper doesn't discover contention — it reveals what was always there.

    Two kinds of revelation:
      1. INTERNAL — the antinom within each event (assertion ↔ negation)
      2. RESONANCE — where events' antinoms amplify each other
    """

    def __init__(self, field: RelationField) -> None:
        self.field = field

    def reveal(self) -> ContentionReport:
        """
        Reveal all contention in the field.

        Pass 1: Internal antinom intensity — how active is the antinom within each event?
        Pass 2: Resonance contention — where do events' antinoms create shared tension?
        Pass 3: Phase co-existence tension — where do co-existing phases conflict? (P7)
        """
        report = ContentionReport()

        # Pass 1: Internal antinom
        for event in self.field.get_mapped_events():
            severity = self._assess_internal_severity(event)
            if severity:
                mark = self.field.reveal_contention(
                    event_position=event.surface_position,
                    severity=severity,
                    description=(
                        f'{event.word}({event.symbol}) carries {event.antinom_word}'
                        f'({event.antinom_symbol}): {event.antinom_note}'
                    ),
                    antinom_pair=f'{event.symbol} ↔ {event.antinom_symbol}',
                )
                report.internal_contentions.append(mark)

        # Pass 2: Resonance contention
        for res in self.field.get_all_resonances():
            if res.resonance_type == RelationType.CONTRADICTS:
                event_a = self.field.get_event(res.event_a_pos)
                event_b = self.field.get_event(res.event_b_pos)
                if event_a and event_b:
                    severity = Severity.VISOKA  # explicit contradiction
                    mark = self.field.reveal_contention(
                        event_position=res.event_a_pos,
                        severity=severity,
                        description=(
                            f'{event_a.word} CONTRADICTS {event_b.word}: {res.note}. '
                            f'Co-existing antinom: {res.antinom_note}'
                        ),
                        antinom_pair=f'{event_a.symbol} ↔ {event_b.symbol}',
                    )
                    report.resonance_contentions.append(mark)

        # Pass 3: Phase co-existence tension (P7)
        events = self.field.get_mapped_events()
        for i, event_a in enumerate(events):
            for event_b in events[i + 1:]:
                shared = set(event_a.co_phases) & set(event_b.co_phases)
                if not shared:
                    continue
                # They share a phase — but do their symbols oppose within that shared phase?
                if _symbols_in_tension_external(event_a.symbol, event_b.symbol):
                    phase_key = (
                        min(event_a.co_phases[0] if event_a.co_phases else 0,
                            event_b.co_phases[0] if event_b.co_phases else 0),
                        max(event_a.co_phases[-1] if event_a.co_phases else 0,
                            event_b.co_phases[-1] if event_b.co_phases else 0),
                    )
                    tension_desc = PHASE_TENSIONS.get(phase_key, f'phase co-existence: {event_a.co_phases} & {event_b.co_phases}')
                    severity = Severity.SREDNJA
                    if abs(event_a.co_phases[0] - event_b.co_phases[0]) >= 3 if event_a.co_phases and event_b.co_phases else False:
                        severity = Severity.VISOKA
                    mark = self.field.reveal_contention(
                        event_position=event_a.surface_position,
                        severity=severity,
                        description=f'Phase tension: {tension_desc}',
                        antinom_pair=f'phases {event_a.co_phases} ↔ {event_b.co_phases}',
                    )
                    report.resonance_contentions.append(mark)

        # Compile
        report.total_contentions = len(report.internal_contentions) + len(report.resonance_contentions)
        report.high_severity_count = sum(
            1 for m in report.internal_contentions + report.resonance_contentions
            if m.severity == Severity.VISOKA
        )
        report.summary = self._build_summary(report)
        return report

    def _assess_internal_severity(self, event) -> Optional[Severity]:
        """How active is the antinom within this event? P2."""
        if not event.antinom_symbol:
            return None

        # ∅ ↔ Δ is the core antinomy — always visoka
        pair = {event.symbol, event.antinom_symbol}
        if pair == {'∅', 'Δ'} or pair == {'Δ', '∅'}:
            return Severity.VISOKA
        if pair == {'¬', '∴'} or pair == {'∴', '¬'}:
            return Severity.VISOKA
        if pair == {'⊢', '∅'} or pair == {'∅', '⊢'}:
            return Severity.VISOKA

        # Any symbol opposition is at least srednja
        for a, b, _ in SYMBOL_OPPOSITIONS:
            if (event.symbol == a and event.antinom_symbol == b) or \
               (event.symbol == b and event.antinom_symbol == a):
                return Severity.SREDNJA

        # If co_phases are far apart, srednja
        if len(event.co_phases) >= 2:
            if max(event.co_phases) - min(event.co_phases) >= 3:
                return Severity.SREDNJA

        # Antinom is present but quiet — nizka
        return Severity.NIZKA

    def _build_summary(self, report: ContentionReport) -> str:
        parts: List[str] = []
        parts.append(f'{report.total_contentions} contention sites revealed.')
        parts.append(f'{report.high_severity_count} high-severity.')
        parts.append(f'{len(report.internal_contentions)} internal (within events), '
                     f'{len(report.resonance_contentions)} in resonance (between events).')

        high = [m for m in report.internal_contentions + report.resonance_contentions
                if m.severity == Severity.VISOKA]
        if high:
            parts.append('High-severity:')
            for m in high[:5]:
                parts.append(f'  • {m.description}')
            if len(high) > 5:
                parts.append(f'  ... and {len(high) - 5} more.')
        else:
            parts.append('No high-severity contention. Field is coherent.')

        return '\n'.join(parts)


def _symbols_in_tension_external(sym_a: str, sym_b: str) -> bool:
    if not sym_a or not sym_b:
        return False
    for a, b, _ in SYMBOL_OPPOSITIONS:
        if (sym_a == a and sym_b == b) or (sym_a == b and sym_b == a):
            return True
    return False

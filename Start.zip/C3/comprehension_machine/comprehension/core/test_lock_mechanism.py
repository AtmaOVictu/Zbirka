"""
Test for Lock Mechanism (Obs11) - Field-of-View Model
===================================================
P7: So-obstajanje. Field-of-view test.
"Odpozicijekjesto ne moreš videti vseh pozicij hkrati."

This test verifies:
1. RelationEvent has positions and turn() method
2. turn() returns field_of_view information
3. Field-of-view correctly shows visible vs hidden positions
4. Resistance is computed from the field
"""

from comprehension.core.decomposer import decompose_statement, RelationEvent
from comprehension.core.graph_store import RelationField


def test_basic_turn():
    """Test basic turn functionality with field-of-view."""
    print("\n" + "=" * 60)
    print("TEST 1: Basic turn() with field-of-view")
    print("=" * 60)
    
    # Decompose a statement
    statement = "IS NOT THE WORD"
    events = decompose_statement(statement)
    
    print(f"Statement: {statement}")
    print(f"Events: {[e.word for e in events if e.mapped]}")
    
    # Build field
    field = RelationField()
    for e in events:
        field.add_event(e)
    
    # Get first mapped event
    mapped_events = [e for e in events if e.mapped]
    if not mapped_events:
        print("No mapped events found!")
        return
    
    first_event = mapped_events[0]
    print(f"\nFirst event: {first_event.word} → {first_event.symbol}")
    print(f"Initial positions: {len(first_event.positions)}")
    print(f"Current position: {first_event.current_position}")
    
    # Get initial field-of-view
    initial_fov = first_event._get_field_of_view(first_event.current_position)
    print(f"\nInitial field-of-view:")
    print(f"  Message: {initial_fov['message']}")
    print(f"  Visible positions: {len(initial_fov['visible'])}")
    print(f"  Hidden positions: {len(initial_fov['hidden'])}")
    
    # Turn the event
    print(f"\n--- Turning {first_event.word} ---")
    result = field.turn_event(first_event.surface_position, direction=1)
    
    if result.get('success'):
        print(f"✓ Turn successful")
        print(f"  From position: {result['from_position']}")
        print(f"  To position: {result['to_position']}")
        print(f"  New symbol: {result['new_symbol']}")
        print(f"  Hidden positions: {result['hidden_positions']}")
        
        # Check field-of-view
        if 'field_of_view' in result:
            fov = result['field_of_view']
            print(f"\n  Field-of-view after turn:")
            print(f"    Message: {fov['message']}")
            print(f"    Visible: {len(fov['visible'])} positions")
            for v in fov['visible']:
                print(f"      - Position {v['position']}: {v['symbol']} ({v['status']})")
            print(f"    Hidden: {len(fov['hidden'])} positions")
            
        # Check resistance
        if 'resistance_report' in result:
            print(f"\n  Resistance report: {len(result['resistance_report'])} events pushing back")
            for r in result['resistance_report']:
                print(f"    - {r['event_word']}({r['event_symbol']}): {r['tension']}")
        
        # Check field resistance
        if 'field_resistance' in result:
            print(f"\n  Field resistance:")
            print(f"    Total targets: {result['field_resistance']['total_resistance_targets']}")
        
        # Check field-of-view summary
        if 'field_of_view_summary' in result:
            print(f"\n  Field-of-view summary:")
            print(f"    Message: {result['field_of_view_summary']['message']}")
            print(f"    Observers: {len(result['field_of_view_summary']['observers'])}")
            for obs in result['field_of_view_summary']['observers']:
                tension = " [TENSION]" if obs['has_tension'] else ""
                print(f"      - {obs['observer_word']}({obs['observer_symbol']}) sees {obs['sees_symbol']}{tension}")
    else:
        print(f"✗ Turn failed: {result.get('error')}")


def test_field_of_view_visibility():
    """Test that field-of-view correctly shows visible vs hidden positions."""
    print("\n" + "=" * 60)
    print("TEST 2: Field-of-view visibility logic")
    print("=" * 60)
    
    # Create a simple event with 4 positions
    event = RelationEvent(
        word="TEST",
        surface_position=0,
        divider="t",
        divided="est",
        symbol="Δ",
        role="test role",
        antinom_word="NOT",
        antinom_symbol="¬",
        antinom_note="test ↔ not-test",
        co_phases=[2, 1],
        mapped=True,
    )
    
    # Initialize positions
    event.initialize_positions()
    
    print(f"Event: {event.word}")
    print(f"Total positions: {len(event.positions)}")
    print(f"\nPosition details:")
    for i, pos in enumerate(event.positions):
        print(f"  [{i}] {pos['name']}: symbol={pos['symbol']}, visible={pos.get('visible', True)}")
    
    # Test field-of-view from position 0
    print(f"\n--- Field-of-view from position 0 ---")
    fov0 = event._get_field_of_view(0)
    print(f"Message: {fov0['message']}")
    print(f"Visible positions:")
    for v in fov0['visible']:
        print(f"  - {v['position']}: {v['symbol']} ({v['status']}, visibility={v['visibility']})")
    print(f"Hidden positions:")
    for h in fov0['hidden']:
        print(f"  - {h['position']}: {h['symbol']} ({h['status']})")


def test_resistance_on_turn():
    """Test that turning one event creates resistance in others."""
    print("\n" + "=" * 60)
    print("TEST 3: Field resistance on turn")
    print("=" * 60)
    
    # Use a statement with known symbol tensions
    # IS (Δ) and NOT (¬) should create tension
    statement = "IS NOT"
    events = decompose_statement(statement)
    
    field = RelationField()
    for e in events:
        field.add_event(e)
    
    print(f"Statement: {statement}")
    print(f"Events: {[e.word + '(' + e.symbol + ')' for e in events if e.mapped]}")
    
    # Turn first event and check resistance
    if events and events[0].mapped:
        result = field.turn_event(events[0].surface_position, direction=1)
        
        print(f"\nTurned {events[0].word}:")
        print(f"  Resistance report: {len(result.get('resistance_report', []))} items")
        
        if 'field_resistance' in result:
            print(f"  Field resistance targets: {result['field_resistance']['total_resistance_targets']}")
            for target in result['field_resistance']['resistance_targets']:
                print(f"    - Position {target['position']}: {target['event']}({target['symbol']})")


def run_all_tests():
    """Run all lock mechanism tests."""
    print("\n" + "=" * 60)
    print("TAZV Comprehension Layer - Lock Mechanism Tests")
    print("=" * 60)
    
    test_basic_turn()
    test_field_of_view_visibility()
    test_resistance_on_turn()
    
    print("\n" + "=" * 60)
    print("All tests complete!")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()

"""
Semantic Analysis of TAZV Comprehension Layer Documentation
=========================================================

Analyzes the words from tazv-comprehension-layer-beseda-kot-zaklep.md
and connects them by semantic patterns using the TAZV framework.

P4: Relation is primary. Words emerge from relations, not the other way around.
P7: Co-existing phases. Faze KO-OBSTAJAJO znotraj besede.
"""

from comprehension.core.decomposer import (
    decompose_statement, 
    RelationEvent, 
    DECOMPOSITION_TABLE,
    SYMBOL_PHASE,
    get_symbol_sequence,
    get_antinom_sequence
)
from comprehension.core.graph_store import (
    RelationField, 
    Resonance,
    RelationType,
    SYMBOL_OPPOSITIONS
)
from typing import List, Dict, Optional, Set, Tuple
from collections import defaultdict
import re


# ============================================================================
# 1. EXTRACT WORDS FROM THE DOCUMENT
# ============================================================================

def extract_keywords_from_spec() -> List[str]:
    """
    Extract all meaningful keywords from the spec document.
    Focus on: protocol names, concepts, ontological terms.
    """
    # Keywords from protocols
    protocols = [
        # ANTINOM OPERATOR PROTOCOL
        "ANTINOM", "OPERATOR", "PROTOCOL",
        "A0", "A1", "A2", "A3", "A4", "A5", "A6",
        "obogati", "negira", "nadomesti", "enrich", "negate", "replace",
        "notranji", "internal", "pogoj", "condition", "razumevanja", "understanding",
        "reši", "resolve", "so-obstajanje", "co-existence", "izbira", "choice",
        "completion", "dokončano", "nedokončano", "incomplete", "prehod", "transition",
        
        # SO-OBSTAJANJE PROTOCOL
        "SO-OBSTAJANJE", "P1", "P2", "P3", "P4", "P5", "P6", "P7",
        "beseda", "word", "relacijski", "relational", "dogodek", "event", "entiteta", "entity",
        "antinom", "counter-statement", "nosi", "carries", "notranjo", "internal", "delitev",
        "division", "reže", "cuts", "razrezano", "divided", "relacija", "relation",
        "primarna", "primary", "svet", "world", "drvi", "pushes", "nazaj", "back",
        "linija", "line", "površje", "surface", "vrstni", "sequential", "red", "order",
        "ontološka", "ontological", "struktura", "structure",
        
        # Core Implementation
        "RelationEvent", "zaklep", "lock", "mehanizem", "mechanism",
        "tumbler", "positions", "current", "locked", "turn", "obrne",
        "field", "resistance", "report", "hidden", "visible", "calculate",
        "pushback", "constraints", "unseen",
        
        # DO_NOT_BUILD
        "DO_NOT_BUILD", "pre-flight", "check", "opozori", "warn", "prepreči", "prevent",
        "comprehension", "user", "for", "struggle", "boj", "cena", "price", "okvara", "damage",
        "canonization", "auto", "manual", "ročna", "odločitev", "decision", "kandidat",
        "kanon", "resnica", "truth", "mora", "must", "preveriti", "verify", "telo", "body",
        "meja", "boundary", "orodje", "tool", "modrost", "wisdom", "module", "pipeline",
        "vprašanje", "question", "pred", "before", "gradnja", "building",
        
        # Ontological
        "Beseda", "WORD", "IS", "NOT", "THE", "NO", "CUT", "TRUTH", "MEANING",
        "FAITH", "DOUBT", "WILL", "BODY", "SOUL", "SPIRIT", "TIME", "MIND",
        "GOD", "SILENCE", "REZ", "cut", "∅", "Δ", "∂", "∮", "⊢", "⧖", "¬", "∴",
        "pomen", "meaning", "resničnost", "reality", "obstajanje", "existence",
        "zaklep", "lock", "krog", "circle", "zanka", "loop",
        "cena", "price", "okvara", "damage", "boj", "struggle",
    ]
    
    # Also extract from the document content
    doc_words = [
        "Comprehension", "realization", "through", "struggle",
        "Boj", "cena", "ne", "okvara",
        "Protokoli", "protocols",
        "Antinom", "operator",
        "Beseda", "kot", "zaklep",
        "polje", "ki", "drvi", "nazaj",
        "pre-flight", "check",
        "implementacija", "core", "implementation",
        "turn", "resistance", "report",
        "field-of-view", "model", "katere", "pozicije", "nevidne", "od", "trenutne",
        "test", "Kaj", "izgubiš", "ko", "obrneš", "tumbler", "morajo", "čutiti", "upor",
        "ne", "le", "videti", "rezultat",
        "preverba", "v", "telesu",
    ]
    
    # Combine and deduplicate
    all_words = list(set(protocols + doc_words))
    
    # Filter to only alphabetic words (remove symbols, numbers)
    filtered = [w for w in all_words if re.match(r'^[a-zA-ZčŠŽśįleetcode\-]+$', w)]
    
    return filtered


# ============================================================================
# 2. ANALYZE WORDS THROUGH DECOMPOSER
# ============================================================================

def analyze_word_semantics(words: List[str]) -> Dict:
    """
    Analyze a list of words through the decomposer to get:
    - Which words map to ontological operators
    - Their symbols, phases, antinoms
    - Clustering by R-7 phases
    """
    results = {
        'mapped_words': [],
        'unmapped_words': [],
        'by_phase': defaultdict(list),
        'by_symbol': defaultdict(list),
        'antinom_pairs': [],
        'phase_coexistence': defaultdict(set),
    }
    
    for word in words:
        event = decompose_statement(word)
        if event and event[0].mapped:
            e = event[0]
            results['mapped_words'].append(word)
            results['by_phase'][tuple(e.co_phases)].append(word)
            results['by_symbol'][e.symbol].append(word)
            
            # Track antinom relationships
            if e.antinom_word:
                results['antinom_pairs'].append({
                    'word': word,
                    'symbol': e.symbol,
                    'antinom': e.antinom_word,
                    'antinom_symbol': e.antinom_symbol,
                })
                
            # Track phase coexistence
            for phase in e.co_phases:
                results['phase_coexistence'][phase].add(word)
        else:
            results['unmapped_words'].append(word)
    
    return results


# ============================================================================
# 3. BUILD SEMANTIC NETWORK
# ============================================================================

def build_semantic_network(analysis: Dict) -> Dict:
    """
    Build a semantic network from the analysis.
    P4: Relation is primary.
    """
    network = {
        'phases': {},
        'symbols': {},
        'antinoms': {},
        'clusters': defaultdict(list),
    }
    
    # 1. Phase-based clustering
    for phases_tuple, words in analysis['by_phase'].items():
        phase_key = ",".join(map(str, phases_tuple))
        network['phases'][phase_key] = {
            'words': words,
            'count': len(words),
        }
    
    # 2. Symbol-based grouping
    for symbol, words in analysis['by_symbol'].items():
        network['symbols'][symbol] = {
            'words': words,
            'count': len(words),
        }
    
    # 3. Antinom pairs
    network['antinoms'] = analysis['antinom_pairs']
    
    # 4. Identify semantic clusters
    # Cluster by shared phases
    phase_word_map = defaultdict(set)
    for word in analysis['mapped_words']:
        events = decompose_statement(word)
        if events and events[0].mapped:
            for phase in events[0].co_phases:
                phase_word_map[phase].add(word)
    
    # Find phases that share many words
    for phase, words in phase_word_map.items():
        phase_name = list(SYMBOL_PHASE.keys())[list(SYMBOL_PHASE.values()).index(phase)] if phase in SYMBOL_PHASE.values() else f"Phase{phase}"
        network['clusters'][phase_name] = list(words)
    
    return network


# ============================================================================
# 4. FIND SEMANTIC PATTERNS
# ============================================================================

def find_semantic_patterns(network: Dict, analysis: Dict) -> Dict:
    """
    Find higher-level semantic patterns:
    - Which phases co-occur most often?
    - Which symbols are in tension?
    - Which words form semantic families?
    """
    patterns = {
        'phase_cooccurrence': defaultdict(int),
        'symbol_tensions': [],
        'semantic_families': defaultdict(list),
        'central_concepts': [],
    }
    
    # 1. Phase co-occurrence
    for phases_tuple, words in analysis['by_phase'].items():
        if len(phases_tuple) > 1:
            for i, p1 in enumerate(phases_tuple):
                for p2 in phases_tuple[i+1:]:
                    key = tuple(sorted([p1, p2]))
                    patterns['phase_cooccurrence'][key] += len(words)
    
    # 2. Symbol tensions (from SYMBOL_OPPOSITIONS)
    for sym1, sym2, desc in SYMBOL_OPPOSITIONS:
        words1 = network['symbols'].get(sym1, {}).get('words', [])
        words2 = network['symbols'].get(sym2, {}).get('words', [])
        if words1 or words2:
            patterns['symbol_tensions'].append({
                'symbols': f"{sym1} ↔ {sym2}",
                'description': desc,
                'words1': words1,
                'words2': words2,
            })
    
    # 3. Semantic families (words that share multiple phases)
    # Group words by their phase signatures
    phase_signatures = defaultdict(list)
    for word in analysis['mapped_words']:
        events = decompose_statement(word)
        if events and events[0].mapped:
            sig = tuple(sorted(events[0].co_phases))
            phase_signatures[sig].append(word)
    
    for sig, words in phase_signatures.items():
        if len(words) > 1:
            phase_names = [list(SYMBOL_PHASE.keys())[list(SYMBOL_PHASE.values()).index(p)] 
                          if p in SYMBOL_PHASE.values() else f"Phase{p}" 
                          for p in sig]
            patterns['semantic_families'][tuple(sig)] = {
                'phases': phase_names,
                'words': words,
                'count': len(words),
            }
    
    # 4. Central concepts (most connected)
    word_connections = defaultdict(int)
    for word in analysis['mapped_words']:
        events = decompose_statement(word)
        if events and events[0].mapped:
            e = events[0]
            # Count connections via antinom
            if e.antinom_word:
                word_connections[word] += 1
            # Count connections via shared phases
            for phase in e.co_phases:
                word_connections[word] += 1
    
    patterns['central_concepts'] = sorted(
        word_connections.items(), 
        key=lambda x: x[1], 
        reverse=True
    )[:10]  # Top 10 most connected
    
    return patterns


# ============================================================================
# 5. VISUALIZE SEMANTIC NETWORK
# ============================================================================

def generate_semantic_report(words: List[str]) -> Dict:
    """
    Generate a comprehensive semantic analysis report.
    """
    print("\n" + "="*80)
    print(" SEMANTIC ANALYSIS OF TAZV COMPREHENSION LAYER DOCUMENTATION")
    print("="*80)
    
    # Step 1: Extract and analyze
    print("\n[1/4] Extracting keywords...")
    keywords = extract_keywords_from_spec()
    print(f"    Found {len(keywords)} unique keywords")
    
    # Step 2: Decompose
    print("[2/4] Analyzing through decomposer...")
    analysis = analyze_word_semantics(keywords)
    print(f"    Mapped: {len(analysis['mapped_words'])} words")
    print(f"    Unmapped: {len(analysis['unmapped_words'])} words")
    
    # Step 3: Build network
    print("[3/4] Building semantic network...")
    network = build_semantic_network(analysis)
    
    # Step 4: Find patterns
    print("[4/4] Finding semantic patterns...")
    patterns = find_semantic_patterns(network, analysis)
    
    # Generate report
    report = {
        'keywords': keywords,
        'analysis': analysis,
        'network': network,
        'patterns': patterns,
    }
    
    return report


def print_semantic_report(report: Dict):
    """Print the semantic analysis report."""
    
    print("\n" + "="*80)
    print(" 📊 SEMANTIC ANALYSIS REPORT")
    print("="*80)
    
    # 1. Overview
    print("\n📈 OVERVIEW")
    print("-" * 40)
    analysis = report['analysis']
    print(f"Total keywords analyzed: {len(report['keywords'])}")
    print(f"Mapped to ontological operators: {len(analysis['mapped_words'])}")
    print(f"Unmapped (no direct operator): {len(analysis['unmapped_words'])}")
    print(f"Mapping ratio: {len(analysis['mapped_words'])/len(report['keywords'])*100:.1f}%")
    
    # 2. Phase Distribution
    print("\n🎯 PHASE DISTRIBUTION (R-7)")
    print("-" * 40)
    network = report['network']
    phase_names = {0: 'BIOS', 1: 'STATE', 2: 'UAF', 3: 'JEWIK', 4: 'APD', 5: 'VIS', 6: 'SO-OBSTAJANJE'}
    
    phase_counts = defaultdict(int)
    for phases_tuple, info in network['phases'].items():
        for p in phases_tuple:
            phase_counts[p] += info['count']
    
    for phase in sorted(phase_counts.keys()):
        name = phase_names.get(phase, f"Phase{phase}")
        bar = "█" * (phase_counts[phase] // 2)
        print(f"  {name:15} ({phase}): {bar} {phase_counts[phase]}")
    
    # 3. Symbol Distribution
    print("\n⚡ SYMBOL DISTRIBUTION")
    print("-" * 40)
    symbol_counts = {k: v['count'] for k, v in network['symbols'].items()}
    for symbol, count in sorted(symbol_counts.items(), key=lambda x: x[1], reverse=True):
        words = ", ".join(network['symbols'][symbol]['words'][:3])
        if len(network['symbols'][symbol]['words']) > 3:
            words += ", ..."
        print(f"  {symbol}: {count:2} words → {words}")
    
    # 4. Antinom Pairs
    print("\n🔄 ANTINOM PAIRS (P2: Every word carries its antinom)")
    print("-" * 40)
    antinoms = report['analysis']['antinom_pairs']
    for pair in antinoms[:10]:  # Show first 10
        print(f"  {pair['word']:15} ({pair['symbol']}) ↔ {pair['antinom']:15} ({pair['antinom_symbol']})")
    if len(antinoms) > 10:
        print(f"  ... and {len(antinoms) - 10} more")
    
    # 5. Phase Co-occurrence
    print("\n🔗 PHASE CO-OCCURRENCE (P7: Co-existing phases)")
    print("-" * 40)
    cooccur = report['patterns']['phase_cooccurrence']
    for phases, count in sorted(cooccur.items(), key=lambda x: x[1], reverse=True)[:5]:
        p1_name = phase_names.get(phases[0], f"Phase{phases[0]}")
        p2_name = phase_names.get(phases[1], f"Phase{phases[1]}")
        print(f"  {p1_name:15} + {p2_name:15}: {count} words")
    
    # 6. Symbol Tensions
    print("\n⚔️  SYMBOL TENSIONS (P5: Resistance field)")
    print("-" * 40)
    tensions = report['patterns']['symbol_tensions']
    for t in tensions[:5]:
        words1 = ", ".join(t['words1'][:2])
        words2 = ", ".join(t['words2'][:2])
        if t['words1'] or t['words2']:
            print(f"  {t['symbols']:20} → {t['description']}")
            if words1: print(f"    {words1}")
            if words2: print(f"    {words2}")
    
    # 7. Semantic Families
    print("\n👨‍👩‍👧‍👦 SEMANTIC FAMILIES (Words sharing phase signatures)")
    print("-" * 40)
    families = report['patterns']['semantic_families']
    for sig, info in sorted(families.items(), key=lambda x: x[1]['count'], reverse=True)[:5]:
        phases_str = ", ".join(info['phases'])
        words_str = ", ".join(info['words'][:5])
        if len(info['words']) > 5:
            words_str += ", ..."
        print(f"  Phases {phases_str:25} → {words_str}")
    
    # 8. Central Concepts
    print("\n🌟 CENTRAL CONCEPTS (Most connected)")
    print("-" * 40)
    central = report['patterns']['central_concepts']
    for word, connections in central:
        print(f"  {word:20} ({connections} connections)")
    
    # 9. Unmapped Words (potential for expansion)
    print("\n❓ UNMAPPED WORDS (No direct ontological operator)")
    print("-" * 40)
    unmapped = analysis['unmapped_words']
    for word in sorted(unmapped)[:10]:
        print(f"  {word}")
    if len(unmapped) > 10:
        print(f"  ... and {len(unmapped) - 10} more")
    
    print("\n" + "="*80)


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    # Run the analysis
    report = generate_semantic_report([])
    
    # Print the report
    print_semantic_report(report)
    
    # Also save to file
    import json
    with open('semantic_analysis_report.json', 'w', encoding='utf-8') as f:
        # Convert to JSON-serializable format
        saveable_report = {
            'keywords': report['keywords'],
            'mapped_words': report['analysis']['mapped_words'],
            'unmapped_words': report['analysis']['unmapped_words'],
            'by_phase': {str(k): v for k, v in report['analysis']['by_phase'].items()},
            'by_symbol': {k: v for k, v in report['analysis']['by_symbol'].items()},
            'phase_cooccurrence': {str(k): v for k, v in report['patterns']['phase_cooccurrence'].items()},
            'central_concepts': dict(report['patterns']['central_concepts']),
        }
        json.dump(saveable_report, f, indent=2, ensure_ascii=False)
    
    print("\n✅ Report saved to semantic_analysis_report.json")

"""
Transformation Tracer — TAZV Comprehension Machine
=============================================
SO-OBSTAJANJE Protocol: traces co-existing resonances, not linear paths (P6/P7).

"DOKAZ is the Product."
⊢ = dokazna sled: kaj se vidi, kaj se ponovi, kaj se preveri.

The old version traced linear paths through nodes (A→B→C→D).
This version traces how the INTERNAL DIVISION of one event
RESONATES with the internal division of another.

DOKAZ is not a path through a graph. DOKAZ is the lineage of
how meaning transforms — through co-existing resonance, not
sequential steps. The trail shows which divisions amplify,
which cancel, which create new possibilities.

JEWIK axioms (validation points):
  JEWIK_001: Beseda je ⊘ (beseda je rez, meja, poseg, dokaz prisotnosti)
  JEWIK_002: ⊘ = univerzalna enota reza, meja, obris, pogoj razlikovanja
  JEWIK_003: ∆ = osnovno gibanje: prehod, sprememba, razlika
  JEWIK_004: ∫ = integracija občutka, spomina, čuta in pomena
  JEWIK_005: ⊢ = dokazna sled: kaj se vidi, kaj se ponovi, kaj se preveri
  JEWIK_006: Vsak pojem mora imeti mejo
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum

from .graph_store import RelationField, Resonance, RelationType


# ── JEWIK Core Axioms ──
JEWIK_AXIOMS: List[Dict] = [
    {'id': 'JEWIK_001', 'statement': 'Beseda je ⊘ (beseda je rez, meja, poseg, dokaz prisotnosti)',
     'symbol': '⊘', 'absoluteness': 0.95, 'type': 'ONTOLOŠKA'},
    {'id': 'JEWIK_002', 'statement': '⊘ = univerzalna enota reza, meja, obris, pogoj razlikovanja',
     'symbol': '⊘', 'absoluteness': 0.92, 'type': 'ONTOLOŠKA'},
    {'id': 'JEWIK_003', 'statement': '∆ = osnovno gibanje: prehod, sprememba, razlika',
     'symbol': '∆', 'absoluteness': 0.90, 'type': 'ONTOLOŠKA'},
    {'id': 'JEWIK_004', 'statement': '∫ = integracija občutka, spomina, čuta in pomena',
     'symbol': '∫', 'absoluteness': 0.85, 'type': 'ONTOLOŠKA'},
    {'id': 'JEWIK_005', 'statement': '⊢ = dokazna sled: kaj se vidi, kaj se ponovi, kaj se preveri',
     'symbol': '⊢', 'absoluteness': 0.88, 'type': 'OPERATIVNA'},
    {'id': 'JEWIK_006', 'statement': 'Vsak pojem mora imeti mejo',
     'symbol': '¬', 'absoluteness': 0.90, 'type': 'OPERATIVNA'},
]
_AXIOM_LOOKUP = {a['id']: a for a in JEWIK_AXIOMS}


# ── Division resonance operators (how one division resonates with another) ──
# Not "∅→¬" (sequential transformation) but "∅∥¬" (co-existing resonance)
RESONANCE_OPERATORS: Dict[str, Dict] = {
    '∅∥Δ': {
        'name': 'void-movement-resonance',
        'description': 'Void resonates with movement — the core antinomy. Stasis and change co-exist.',
        'axiom': 'JEWIK_003',
        'intensity': 1.0,
    },
    '¬∥∴': {
        'name': 'cut-relation-resonance',
        'description': 'Cut resonates with relation — separation and connection co-exist.',
        'axiom': 'JEWIK_006',
        'intensity': 0.9,
    },
    '⊢∥∅': {
        'name': 'proof-void-resonance',
        'description': 'Proof resonates with void — assertion and negation co-exist.',
        'axiom': 'JEWIK_001',
        'intensity': 0.85,
    },
    '∫∥¬': {
        'name': 'presence-cut-resonance',
        'description': 'Presence resonates with cut — sustaining and separating co-exist.',
        'axiom': 'JEWIK_004',
        'intensity': 0.8,
    },
    'δ∥∫': {
        'name': 'passage-presence-resonance',
        'description': 'Passage resonates with presence — the cut that opens and the sustaining flow.',
        'axiom': 'JEWIK_002',
        'intensity': 0.75,
    },
    '⧖∥⊢': {
        'name': 'silence-proof-resonance',
        'description': 'Silence resonates with proof — listening and assertion co-exist.',
        'axiom': 'JEWIK_005',
        'intensity': 0.7,
    },
}


@dataclass
class ResonanceStep:
    """One step in the DOKAZ — a resonance between two events' divisions."""
    step_index: int
    event_a_word: str
    event_a_symbol: str
    event_a_divider: str
    event_a_divided: str
    event_b_word: str
    event_b_symbol: str
    event_b_divider: str
    event_b_divided: str
    resonance_key: str
    resonance_name: str
    description: str
    axiom_ref: Optional[str]
    intensity: float
    # P2: the antinom of this resonance
    antinom_resonance: str = ''

    def __repr__(self) -> str:
        return (f'Step {self.step_index}: '
                f'{self.event_a_word}({self.event_a_symbol}) ∥ '
                f'{self.event_b_word}({self.event_b_symbol}) [{self.resonance_name}]')


@dataclass
class DOKAZ:
    """
    A proof trail — NOT a linear path, but a resonance map.

    "DOKAZ is the Product." — the lineage showing how meaning
    transforms through co-existing resonance (P6/P7), not
    sequential steps.
    """
    statement: str
    events: List[ResonanceStep] = field(default_factory=list)
    total_intensity: float = 0.0
    validated_by_axioms: List[str] = field(default_factory=list)
    trail: str = ''  # human-readable: the resonance map

    def to_dict(self) -> Dict:
        return {
            'statement': self.statement,
            'steps': [
                {
                    'step': s.step_index,
                    'event_a': f'{s.event_a_word}({s.event_a_symbol})',
                    'division_a': f'{s.event_a_divider} | {s.event_a_divided}',
                    'event_b': f'{s.event_b_word}({s.event_b_symbol})',
                    'division_b': f'{s.event_b_divider} | {s.event_b_divided}',
                    'resonance': s.resonance_name,
                    'description': s.description,
                    'axiom': s.axiom_ref,
                    'intensity': s.intensity,
                    'antinom_resonance': s.antinom_resonance,
                }
                for s in self.events
            ],
            'total_intensity': self.total_intensity,
            'validated_by': self.validated_by_axioms,
            'trail': self.trail,
        }


class TransformationTracer:
    """
    Traces how meaning transforms — through co-existing resonance (P6/P7).

    The old tracer followed linear paths through nodes.
    This tracer follows how the INTERNAL DIVISION of one event
    resonates with the INTERNAL DIVISION of another.

    DOKAZ = the resonance map. Not "A became B" but
    "A's division resonates with B's division, and here is the proof."
    """

    def __init__(self, field: RelationField) -> None:
        self.field = field

    def trace_statement(self, statement: str) -> DOKAZ:
        """
        Trace the resonance map of an entire statement.

        For every pair of mapped events, check if their divisions
        resonate. Record each resonance as a step in the DOKAZ.
        """
        dokaz = DOKAZ(statement=statement)
        events = self.field.get_mapped_events()
        axioms_used: List[str] = []
        intensity_product = 1.0

        step_idx = 0
        trail_parts: List[str] = []

        for i, event_a in enumerate(events):
            for event_b in events[i + 1:]:
                resonance = self._check_resonance(event_a, event_b)
                if resonance:
                    op_key, operator = resonance

                    if operator['axiom'] and operator['axiom'] not in axioms_used:
                        axioms_used.append(operator['axiom'])

                    intensity_product *= operator['intensity']

                    step = ResonanceStep(
                        step_index=step_idx,
                        event_a_word=event_a.word,
                        event_a_symbol=event_a.symbol,
                        event_a_divider=event_a.divider,
                        event_a_divided=event_a.divided,
                        event_b_word=event_b.word,
                        event_b_symbol=event_b.symbol,
                        event_b_divider=event_b.divider,
                        event_b_divided=event_b.divided,
                        resonance_key=op_key,
                        resonance_name=operator['name'],
                        description=operator['description'],
                        axiom_ref=operator.get('axiom'),
                        intensity=operator['intensity'],
                        antinom_resonance=(
                            f'{event_a.antinom_word}({event_a.antinom_symbol}) ∥ '
                            f'{event_b.antinom_word}({event_b.antinom_symbol})'
                        ),
                    )
                    dokaz.events.append(step)
                    trail_parts.append(
                        f'{event_a.word}({event_a.symbol})∥{event_b.word}({event_b.symbol})'
                    )
                    step_idx += 1

        dokaz.total_intensity = intensity_product if dokaz.events else 0.0
        dokaz.validated_by_axioms = axioms_used
        dokaz.trail = ' ∥ '.join(trail_parts) if trail_parts else '(no resonances found)'

        return dokaz

    def _check_resonance(self, event_a, event_b) -> Optional[tuple]:
        """Check if two events' divisions resonate."""
        # Try all orderings of their symbols
        for sym_a, sym_b in [
            (event_a.symbol, event_b.symbol),
            (event_b.symbol, event_a.symbol),
            (event_a.antinom_symbol, event_b.symbol),
            (event_a.symbol, event_b.antinom_symbol),
            (event_a.antinom_symbol, event_b.antinom_symbol),
        ]:
            if not sym_a or not sym_b:
                continue
            key = f'{sym_a}∥{sym_b}'
            if key in RESONANCE_OPERATORS:
                return key, RESONANCE_OPERATORS[key]
        return None

    def get_axiom_validation(self, dokaz: DOKAZ) -> List[Dict]:
        """Get the full JEWIK axiom texts that validate this DOKAZ."""
        return [_AXIOM_LOOKUP[aid] for aid in dokaz.validated_by_axioms
                if aid in _AXIOM_LOOKUP]
